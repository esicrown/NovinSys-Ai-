import { CameraDeviceInfo } from '../types';

/**
 * Camera Stream & Capture Service
 * Manages video streams for Front (Driver) and Rear (Road) cameras,
 * multi-camera selection, best default rear camera detection,
 * 360-degree camera quality matching, and torch API flashlight trigger.
 */
export class CameraService {
  /**
   * Default simulated fallback camera list when running in browser sandbox without physical multi-cams
   */
  public static readonly FALLBACK_CAMERAS: CameraDeviceInfo[] = [
    {
      deviceId: 'sim-rear-main-0',
      label: 'دوربین پشت اصلی (Primary Rear 4K/1080p)',
      facing: 'rear',
      isPrimaryRear: true,
      qualityTag: 'کیفیت عالی (4K / 60fps) - پیش‌فرض هوشمند',
    },
    {
      deviceId: 'sim-rear-ultrawide-1',
      label: 'دوربین فوق عریض پشت (Ultra Wide 0.5x)',
      facing: 'rear',
      isPrimaryRear: false,
      qualityTag: 'دید عریض ۱۲۰ درجه (1080p)',
    },
    {
      deviceId: 'sim-rear-tele-2',
      label: 'دوربین تله‌فوتو پشت (Telephoto 2x Zoom)',
      facing: 'rear',
      isPrimaryRear: false,
      qualityTag: 'زوم ۲ برابر (1080p)',
    },
    {
      deviceId: 'sim-front-main-0',
      label: 'دوربین جلو سلفی (Front Self-Cam HD)',
      facing: 'front',
      isPrimaryRear: false,
      qualityTag: 'پایش چهره راننده (1080p / 30fps)',
    },
  ];

  /**
   * Enumerates all video devices and returns rich camera details with best rear camera auto-tagging
   */
  public static async getAvailableVideoDevices(): Promise<CameraDeviceInfo[]> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      return CameraService.FALLBACK_CAMERAS;
    }

    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const videoInputs = devices.filter((d) => d.kind === 'videoinput');

      if (videoInputs.length === 0) {
        return CameraService.FALLBACK_CAMERAS;
      }

      let primaryRearFound = false;
      const parsedDevices: CameraDeviceInfo[] = videoInputs.map((device, idx) => {
        const labelLower = (device.label || '').toLowerCase();
        let facing: 'front' | 'rear' | 'external' = 'rear';

        if (
          labelLower.includes('front') ||
          labelLower.includes('user') ||
          labelLower.includes('جلو') ||
          labelLower.includes('selfie')
        ) {
          facing = 'front';
        } else if (
          labelLower.includes('back') ||
          labelLower.includes('rear') ||
          labelLower.includes('environment') ||
          labelLower.includes('پشت') ||
          labelLower.includes('main')
        ) {
          facing = 'rear';
        } else {
          facing = idx === 0 ? 'front' : 'rear';
        }

        let qualityTag = '1080p / HD';
        let isPrimary = false;

        if (facing === 'rear') {
          if (
            !primaryRearFound &&
            (labelLower.includes('0') ||
              labelLower.includes('main') ||
              labelLower.includes('primary') ||
              labelLower.includes('back 0') ||
              labelLower.includes('wide'))
          ) {
            isPrimary = true;
            primaryRearFound = true;
            qualityTag = 'کیفیت عالی (4K/1080p) - پیش‌فرض هوشمند';
          } else if (labelLower.includes('ultra') || labelLower.includes('wide')) {
            qualityTag = 'فوق عریض (Ultra-Wide 0.5x)';
          } else if (labelLower.includes('tele')) {
            qualityTag = 'تله‌فوتو (Telephoto 2x)';
          }
        } else {
          qualityTag = 'پایش چهره راننده (HD)';
        }

        const fallbackLabel =
          facing === 'rear'
            ? `دوربین پشت ${idx + 1} (${isPrimary ? 'اصلی' : 'فرعی'})`
            : `دوربین جلو ${idx + 1}`;

        return {
          deviceId: device.deviceId,
          label: device.label || fallbackLabel,
          facing,
          isPrimaryRear: isPrimary,
          qualityTag,
        };
      });

      // If no rear camera was tagged primary yet, tag the first rear camera
      if (!primaryRearFound) {
        const firstRear = parsedDevices.find((d) => d.facing === 'rear');
        if (firstRear) {
          firstRear.isPrimaryRear = true;
          firstRear.qualityTag = 'کیفیت اصلی (پیش‌فرض هوشمند)';
        }
      }

      return parsedDevices;
    } catch (e) {
      console.warn('Could not enumerate devices:', e);
      return CameraService.FALLBACK_CAMERAS;
    }
  }

  /**
   * Acquire dual camera streams simultaneously:
   * Front (User) camera for Driver Monitoring
   * Rear (Environment) camera for Road AI Monitoring
   * Respects user-selected camera device IDs or picks best rear camera default.
   */
  public static async getDualCameraStreams(
    selectedRearId = 'auto',
    selectedFrontId = 'auto'
  ): Promise<{
    driverStream: MediaStream | null;
    roadStream: MediaStream | null;
    hasSeparateCameras: boolean;
    availableCameras: CameraDeviceInfo[];
    bestRearCameraId: string;
    best360RearCameraId: string;
  }> {
    const availableCameras = await CameraService.getAvailableVideoDevices();

    // Determine Best Rear Camera default
    const primaryRear = availableCameras.find((c) => c.facing === 'rear' && c.isPrimaryRear) ||
      availableCameras.find((c) => c.facing === 'rear') ||
      availableCameras[0];

    const bestRearCameraId = primaryRear ? primaryRear.deviceId : 'auto';

    // Determine Best Front Camera
    const primaryFront = availableCameras.find((c) => c.facing === 'front') || availableCameras[0];
    const bestFrontCameraId = primaryFront ? primaryFront.deviceId : 'auto';

    // Best 360 Rear Camera: matches or closest to front camera resolution/quality (defaults to primary rear)
    const best360RearCameraId = bestRearCameraId;

    const targetRearId = selectedRearId && selectedRearId !== 'auto' ? selectedRearId : bestRearCameraId;
    const targetFrontId = selectedFrontId && selectedFrontId !== 'auto' ? selectedFrontId : bestFrontCameraId;

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      console.warn('getUserMedia not supported in this browser.');
      return {
        driverStream: null,
        roadStream: null,
        hasSeparateCameras: false,
        availableCameras,
        bestRearCameraId,
        best360RearCameraId,
      };
    }

    try {
      let driverStream: MediaStream | null = null;
      let roadStream: MediaStream | null = null;

      // 1. Attempt explicit deviceId fetch
      if (targetFrontId && targetFrontId !== 'auto') {
        try {
          driverStream = await navigator.mediaDevices.getUserMedia({
            video: { deviceId: { exact: targetFrontId }, width: { ideal: 1280 }, height: { ideal: 720 } },
            audio: false,
          });
        } catch (e) {
          console.warn('Selected Front camera deviceId fetch failed, falling back:', e);
        }
      }

      if (targetRearId && targetRearId !== 'auto') {
        try {
          roadStream = await navigator.mediaDevices.getUserMedia({
            video: { deviceId: { exact: targetRearId }, width: { ideal: 1280 }, height: { ideal: 720 } },
            audio: false,
          });
        } catch (e) {
          console.warn('Selected Rear camera deviceId fetch failed, falling back:', e);
        }
      }

      // 2. Fallbacks by facingMode if specific deviceId failed or was 'auto'
      if (!driverStream) {
        try {
          driverStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: 'user' }, width: { ideal: 1280 }, height: { ideal: 720 } },
            audio: false,
          });
        } catch (e) {
          console.warn('Could not get user camera:', e);
        }
      }

      if (!roadStream) {
        try {
          roadStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
            audio: false,
          });
        } catch (e) {
          console.warn('Could not get environment camera:', e);
        }
      }

      const driverTrack = driverStream?.getVideoTracks()[0];
      const roadTrack = roadStream?.getVideoTracks()[0];

      // If browser returned the same stream track for both calls, avoid locking single camera
      if (driverTrack && roadTrack && driverTrack.id === roadTrack.id) {
        console.warn('Hardware has only 1 active camera. Driver gets real camera, Road uses AI simulation.');
        roadStream?.getTracks().forEach((t) => t.stop());
        return {
          driverStream,
          roadStream: null,
          hasSeparateCameras: false,
          availableCameras,
          bestRearCameraId,
          best360RearCameraId,
        };
      }

      const hasSeparateCameras = Boolean(driverStream && roadStream && driverTrack?.id !== roadTrack?.id);

      return {
        driverStream,
        roadStream,
        hasSeparateCameras,
        availableCameras,
        bestRearCameraId,
        best360RearCameraId,
      };
    } catch (err) {
      console.error('Error fetching dual cameras:', err);
      return {
        driverStream: null,
        roadStream: null,
        hasSeparateCameras: false,
        availableCameras,
        bestRearCameraId,
        best360RearCameraId,
      };
    }
  }

  /**
   * Stops all tracks of a given MediaStream safely to release camera hardware
   */
  public static stopStream(stream: MediaStream | null): void {
    if (!stream) return;
    try {
      stream.getTracks().forEach((track) => {
        track.stop();
      });
    } catch (e) {
      console.warn('Could not stop stream tracks:', e);
    }
  }

  /**
   * Request media stream for single camera by device ID or facingMode.
   * Automatically picks the highest quality primary rear camera (4K/1080p) for environment mode.
   */
  public static async getSingleCameraStream(
    deviceId?: string,
    facingMode: 'user' | 'environment' = 'environment'
  ): Promise<MediaStream | null> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return null;
    }

    try {
      let targetId = deviceId;

      // When requesting rear camera without specific device ID, auto-pick best primary 4K/1080p rear camera
      if (facingMode === 'environment' && (!targetId || targetId === 'auto')) {
        const devices = await CameraService.getAvailableVideoDevices();
        const primaryRear = devices.find((d) => d.facing === 'rear' && d.isPrimaryRear) ||
          devices.find((d) => d.facing === 'rear');
        if (primaryRear) {
          targetId = primaryRear.deviceId;
        }
      }

      if (targetId && targetId !== 'auto' && !targetId.startsWith('sim-')) {
        try {
          return await navigator.mediaDevices.getUserMedia({
            video: {
              deviceId: { exact: targetId },
              width: { ideal: facingMode === 'environment' ? 3840 : 1280, min: 1280 },
              height: { ideal: facingMode === 'environment' ? 2160 : 720, min: 720 },
              frameRate: { ideal: 60 },
            },
            audio: false,
          });
        } catch (e) {
          console.warn('Exact deviceId getUserMedia failed, falling back to facingMode:', e);
        }
      }

      return await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: facingMode === 'environment' ? 3840 : 1280 },
          height: { ideal: facingMode === 'environment' ? 2160 : 720 },
          frameRate: { ideal: 60 },
        },
        audio: false,
      });
    } catch (err) {
      console.warn('getSingleCameraStream error:', err);
      return null;
    }
  }

  /**
   * Captures snapshot frame from an HTMLVideoElement or Canvas
   */
  public static captureSnapshot(videoEl: HTMLVideoElement | null, title: string): string {
    const canvas = document.createElement('canvas');
    if (videoEl && videoEl.readyState >= 2 && videoEl.videoWidth > 0) {
      canvas.width = videoEl.videoWidth;
      canvas.height = videoEl.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
        return canvas.toDataURL('image/jpeg', 0.85);
      }
    }

    // Fallback simulated canvas snapshot
    canvas.width = 640;
    canvas.height = 360;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, 640, 360);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(20, 20, 600, 320);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 24px Vazirmatn, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`تصویر ثبت‌شده: ${title}`, 320, 170);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '16px Vazirmatn, sans-serif';
      ctx.fillText(new Date().toLocaleTimeString('fa-IR'), 320, 210);
      return canvas.toDataURL('image/jpeg', 0.85);
    }

    return '';
  }

  /**
   * Attempts to pulse device LED flash / torch if supported
   */
  public static async pulseHardwareFlash(stream: MediaStream | null, durationMs = 2000): Promise<boolean> {
    if (!stream) return false;
    try {
      const track = stream.getVideoTracks()[0];
      if (!track) return false;

      const capabilities = (track as unknown as { getCapabilities?: () => Record<string, unknown> }).getCapabilities?.();
      if (capabilities && 'torch' in capabilities) {
        await (track as unknown as { applyConstraints: (c: Record<string, unknown>) => Promise<void> }).applyConstraints({
          advanced: [{ torch: true }],
        });

        setTimeout(async () => {
          try {
            await (track as unknown as { applyConstraints: (c: Record<string, unknown>) => Promise<void> }).applyConstraints({
              advanced: [{ torch: false }],
            });
          } catch (e) {
            // ignore
          }
        }, durationMs);

        return true;
      }
    } catch (err) {
      console.warn('Flashlight torch not supported on track:', err);
    }
    return false;
  }
}
