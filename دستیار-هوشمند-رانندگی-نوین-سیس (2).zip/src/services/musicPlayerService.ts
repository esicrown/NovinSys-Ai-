import { AudioTrack } from '../types';

export class MusicPlayerService {
  private audioElement: HTMLAudioElement | null = null;
  private isPlaying = false;
  private currentTrackIndex = 0;
  private baseVolume = 0.50; // 50% base
  private currentAppliedVolume = 0.50;
  private tracks: AudioTrack[] = [
    { id: '1', title: 'جاده و آرامش', artist: 'نوین سیس ارکستر', album: 'سفر بی خطر', durationStr: '03:45' },
    { id: '2', title: 'آوای کویر', artist: 'موسیقی سنتی', album: 'طبیعت ایران', durationStr: '04:20' },
    { id: '3', title: 'ریتم سفر ایمن', artist: 'موزیک رانندگی', album: 'همراه جاده', durationStr: '03:12' },
  ];
  private speedBoostState: 'none' | 'boost90' | 'boost130' = 'none';

  constructor() {
    this.initAudio();
  }

  private initAudio() {
    if (typeof window !== 'undefined') {
      this.audioElement = new Audio();
      this.audioElement.volume = this.baseVolume;
      this.audioElement.onended = () => this.playNextTrack();
    }
  }

  public getPlaylist(): AudioTrack[] {
    return this.tracks;
  }

  public getCurrentTrack(): AudioTrack | null {
    return this.tracks[this.currentTrackIndex] || null;
  }

  public getPlaybackStatus() {
    return {
      isPlaying: this.isPlaying,
      track: this.getCurrentTrack(),
      volumePct: Math.round(this.currentAppliedVolume * 100),
      speedBoostLevel: this.speedBoostState,
    };
  }

  public togglePlayPause(): boolean {
    if (!this.audioElement) return false;

    if (this.isPlaying) {
      this.audioElement.pause();
      this.isPlaying = false;
    } else {
      this.audioElement.play().catch(() => {
        // Fallback simulated play state if no local audio stream file
        console.warn('Audio play simulated (no local stream provided)');
      });
      this.isPlaying = true;
    }
    return this.isPlaying;
  }

  public playNextTrack(): AudioTrack | null {
    this.currentTrackIndex = (this.currentTrackIndex + 1) % this.tracks.length;
    if (this.isPlaying && this.audioElement) {
      this.audioElement.play().catch(() => {});
    }
    return this.getCurrentTrack();
  }

  public playPrevTrack(): AudioTrack | null {
    this.currentTrackIndex = (this.currentTrackIndex - 1 + this.tracks.length) % this.tracks.length;
    if (this.isPlaying && this.audioElement) {
      this.audioElement.play().catch(() => {});
    }
    return this.getCurrentTrack();
  }

  /**
   * Evaluates vehicle GPS speed and auto-adjusts music volume!
   * @param speedKmH Current speed in km/h
   * @returns Object with boost change info if volume modified
   */
  public updateVolumeForSpeed(speedKmH: number, smartMusicEnabled: boolean): { boostChanged: boolean; newVolumePct: number; level: string } {
    if (!smartMusicEnabled) {
      return { boostChanged: false, newVolumePct: Math.round(this.baseVolume * 100), level: 'off' };
    }

    // Auto-start music if driving (> 10 km/h) and not already playing
    if (speedKmH > 10 && !this.isPlaying) {
      this.togglePlayPause();
    }

    let targetVolume = this.baseVolume;
    let newBoostState: 'none' | 'boost90' | 'boost130' = 'none';

    if (speedKmH >= 130) {
      // Speed >= 130: Boost +20 levels total (e.g., 50% -> 70%)
      targetVolume = Math.min(1.0, this.baseVolume + 0.20);
      newBoostState = 'boost130';
    } else if (speedKmH >= 90) {
      // Speed >= 90: Boost +10 levels (e.g., 50% -> 60%)
      targetVolume = Math.min(1.0, this.baseVolume + 0.10);
      newBoostState = 'boost90';
    } else {
      // Normal speed < 90 km/h: Base volume
      targetVolume = this.baseVolume;
      newBoostState = 'none';
    }

    const changed = newBoostState !== this.speedBoostState;
    this.speedBoostState = newBoostState;
    this.currentAppliedVolume = targetVolume;

    if (this.audioElement) {
      this.audioElement.volume = targetVolume;
    }

    return {
      boostChanged: changed,
      newVolumePct: Math.round(targetVolume * 100),
      level: newBoostState,
    };
  }

  public setBaseVolume(vol0to100: number) {
    this.baseVolume = Math.max(0, Math.min(100, vol0to100)) / 100;
    this.currentAppliedVolume = this.baseVolume;
    if (this.audioElement) {
      this.audioElement.volume = this.baseVolume;
    }
  }
}

export const musicPlayerService = new MusicPlayerService();
