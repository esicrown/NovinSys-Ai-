/**
 * Audio Alert & Persian Speech Service
 * Provides loud Web Audio API siren for Drowsiness alert
 * and Persian Web Speech API synthesis for road warnings.
 */

class AudioAlertService {
  private audioCtx: AudioContext | null = null;
  private sirenOscillator: OscillatorNode | null = null;
  private sirenGainNode: GainNode | null = null;
  private isSirenActive = false;
  private speechUtterance: SpeechSynthesisUtterance | null = null;
  private lastSpokenAlerts: Map<string, number> = new Map();

  constructor() {
    // Lazy init audio context on first user interaction
  }

  private getAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtxClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  /**
   * Starts loud high-priority Siren Alarm for Driver Drowsiness
   * Cannot be silenced by device volume controls or dismiss button —
   * stays active until eyes are confirmed open.
   */
  public startDrowsinessSiren() {
    if (this.isSirenActive) return;

    try {
      const ctx = this.getAudioContext();
      this.sirenOscillator = ctx.createOscillator();
      this.sirenGainNode = ctx.createGain();

      // High visibility square wave siren
      this.sirenOscillator.type = 'sawtooth';
      
      // Frequency siren oscillation (800Hz to 1400Hz oscillating)
      const now = ctx.currentTime;
      this.sirenOscillator.frequency.setValueAtTime(800, now);
      
      // Oscillate frequency over time
      let freqDirection = 1;
      const sirenInterval = setInterval(() => {
        if (!this.isSirenActive || !this.sirenOscillator || !this.audioCtx) {
          clearInterval(sirenInterval);
          return;
        }
        const currentFreq = this.sirenOscillator.frequency.value;
        if (currentFreq >= 1500) freqDirection = -1;
        if (currentFreq <= 700) freqDirection = 1;
        this.sirenOscillator.frequency.setValueAtTime(currentFreq + (freqDirection * 100), ctx.currentTime);
      }, 50);

      // Set volume gain to maximum (loud override)
      this.sirenGainNode.gain.setValueAtTime(0.85, now);

      this.sirenOscillator.connect(this.sirenGainNode);
      this.sirenGainNode.connect(ctx.destination);

      this.sirenOscillator.start(now);
      this.isSirenActive = true;

      // Speak Persian voice urgent warning concurrently
      this.speakPersian('هشدار! راننده عزیز چشمان خود را باز کنید! خطر خواب‌آلودگی!', true);
    } catch (err) {
      console.warn('Audio Context error starting siren:', err);
    }
  }

  /**
   * Stops the Drowsiness Siren immediately when eyes open
   */
  public stopDrowsinessSiren() {
    if (!this.isSirenActive) return;

    try {
      if (this.sirenOscillator) {
        this.sirenOscillator.stop();
        this.sirenOscillator.disconnect();
        this.sirenOscillator = null;
      }
      if (this.sirenGainNode) {
        this.sirenGainNode.disconnect();
        this.sirenGainNode = null;
      }
      this.isSirenActive = false;
    } catch (err) {
      console.warn('Error stopping siren:', err);
    }
  }

  /**
   * Speaks Persian voice warning using Web Speech API
   */
  public speakPersian(text: string, forcePriority = false) {
    if (!('speechSynthesis' in window)) return;

    // Avoid repeating same alert within 6 seconds unless forced
    const now = Date.now();
    const lastTime = this.lastSpokenAlerts.get(text) || 0;
    if (!forcePriority && now - lastTime < 6000) {
      return;
    }

    this.lastSpokenAlerts.set(text, now);

    try {
      // Cancel previous speech if priority
      if (forcePriority) {
        window.speechSynthesis.cancel();
      }

      this.speechUtterance = new SpeechSynthesisUtterance(text);
      this.speechUtterance.lang = 'fa-IR';
      this.speechUtterance.rate = 1.0;
      this.speechUtterance.pitch = 1.0;

      // Try to find Persian voice if available, fallback to default
      const voices = window.speechSynthesis.getVoices();
      const persianVoice = voices.find(v => v.lang.includes('fa') || v.lang.includes('IR') || v.name.toLowerCase().includes('persian'));
      if (persianVoice) {
        this.speechUtterance.voice = persianVoice;
      }

      window.speechSynthesis.speak(this.speechUtterance);
    } catch (err) {
      console.warn('Speech synthesis error:', err);
    }
  }

  /**
   * Short chime sound for info/warnings
   */
  public playWarningBeep() {
    try {
      const ctx = this.getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {
      // ignore
    }
  }
}

export const audioAlertService = new AudioAlertService();
