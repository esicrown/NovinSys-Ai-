import React from 'react';
import { X, Camera, Download, Trash2, Calendar, Eye } from 'lucide-react';
import { MediaSnapshot } from '../types';

interface GalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  snapshots: MediaSnapshot[];
  onDeleteSnapshot: (id: string) => void;
}

export const GalleryModal: React.FC<GalleryModalProps> = ({
  isOpen,
  onClose,
  snapshots,
  onDeleteSnapshot,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2 text-emerald-400">
            <Camera className="w-5 h-5" />
            <h2 className="font-extrabold text-base">گالری عکس‌های ضبط‌شده با دوربین (driver & road)</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 flex-1 overflow-y-auto">
          {snapshots.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-slate-500 space-y-2 text-center">
              <Camera className="w-12 h-12 stroke-[1.5]" />
              <p className="text-sm font-medium">هنوز هیچ عکسی ثبت نشده است.</p>
              <p className="text-xs text-slate-600">با لمس تصویر دوربین جلو یا پشت، عکس ثبت می‌شود.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {snapshots.map((s) => (
                <div
                  key={s.id}
                  className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden group flex flex-col justify-between"
                >
                  <div className="relative aspect-video bg-slate-900 overflow-hidden">
                    <img src={s.dataUrl} alt={s.title} className="w-full h-full object-cover" />
                    <span className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur px-2 py-0.5 rounded text-[9px] font-bold text-emerald-400 border border-slate-700">
                      {s.source === 'driver' ? 'دوربین جلو' : 'دوربین پشت'}
                    </span>
                  </div>

                  <div className="p-2.5 flex items-center justify-between text-xs">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-200">{s.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(s.timestamp).toLocaleTimeString('fa-IR')}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <a
                        href={s.dataUrl}
                        download={`snapshot_${s.id}.jpg`}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600 hover:text-slate-950 text-slate-300 transition-colors"
                        title="دانلود عکس"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => onDeleteSnapshot(s.id)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-600 hover:text-white text-slate-400 transition-colors"
                        title="حذف"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
