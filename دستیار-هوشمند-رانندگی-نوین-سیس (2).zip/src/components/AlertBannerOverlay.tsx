import React, { useEffect } from 'react';
import { AlertOctagon, AlertTriangle, Info, X, EyeOff } from 'lucide-react';
import { AlertItem } from '../types';

interface AlertBannerOverlayProps {
  activeAlert: AlertItem | null;
  onDismissAlert: (id: string) => void;
  isDrowsySirenActive: boolean;
}

export const AlertBannerOverlay: React.FC<AlertBannerOverlayProps> = ({
  activeAlert,
  onDismissAlert,
}) => {
  useEffect(() => {
    if (!activeAlert) return;

    // Persistent alerts stay active until condition clears (e.g. eyes open)
    if (activeAlert.persistentUntilEyeOpen) {
      return;
    }

    // Default duration is 5 seconds (5000ms) as requested
    const duration = activeAlert.durationMs || 5000;

    const timer = setTimeout(() => {
      onDismissAlert(activeAlert.id);
    }, duration);

    return () => clearTimeout(timer);
  }, [activeAlert, onDismissAlert]);

  if (!activeAlert) return null;

  const isDanger = activeAlert.severity === 'danger';
  const isWarning = activeAlert.severity === 'warning';

  return (
    <div className="fixed top-2 left-2 right-2 z-50 pointer-events-auto max-w-xl mx-auto transition-all">
      <div
        className={`relative w-full p-3 rounded-2xl border shadow-2xl backdrop-blur-xl flex items-center justify-between gap-3 text-slate-100 ${
          isDanger
            ? 'bg-red-950/95 border-red-500 text-white shadow-red-900/50'
            : isWarning
            ? 'bg-amber-950/95 border-amber-500 text-amber-100 shadow-amber-900/50'
            : 'bg-emerald-950/95 border-emerald-500 text-emerald-100 shadow-emerald-900/50'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center font-black flex-shrink-0 shadow-lg ${
              isDanger
                ? 'bg-red-600 text-white animate-pulse'
                : isWarning
                ? 'bg-amber-500 text-slate-950'
                : 'bg-emerald-500 text-slate-950'
            }`}
          >
            {isDanger ? (
              <AlertOctagon className="w-5 h-5" />
            ) : isWarning ? (
              <AlertTriangle className="w-5 h-5" />
            ) : (
              <Info className="w-5 h-5" />
            )}
          </div>

          <div className="flex flex-col text-right">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xs">{activeAlert.title}</span>
            </div>
            <p className="text-[11px] opacity-90 mt-0.5 font-medium">{activeAlert.message}</p>
          </div>
        </div>

        {/* Right side dismiss button */}
        <div className="flex items-center gap-2">
          {!activeAlert.persistentUntilEyeOpen ? (
            <button
              onClick={() => onDismissAlert(activeAlert.id)}
              className="p-1 rounded-lg hover:bg-slate-800/80 text-slate-400 hover:text-white transition-colors"
              title="بستن"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <div className="bg-red-600 text-white text-[10px] px-2 py-1 rounded-lg font-bold flex items-center gap-1 animate-pulse">
              <EyeOff className="w-3.5 h-3.5" />
              <span>پایش چهره</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

