import React, { useState, useEffect, useRef } from 'react';
import {
  Navigation,
  Search,
  ExternalLink,
  Compass,
  Smartphone,
  Check,
  AlertCircle,
} from 'lucide-react';
import L from 'leaflet';
import { NavAppId, NavAppConfig } from '../types';

interface NavigationAppViewProps {
  selectedAppId: NavAppId;
  currentSpeedKmH: number;
  speedLimitKmH: number;
  currentInstruction: string;
  onSelectApp?: (appId: NavAppId) => void;
}

export const NAV_APPS: Record<
  NavAppId,
  NavAppConfig & {
    intentUrl: (query: string) => string;
    searchUrl: (query: string) => string;
    packageName: string;
  }
> = {
  neshan: {
    id: 'neshan',
    nameFa: 'مسیریاب نشان',
    nameEn: 'Neshan Navigation',
    iconBg: 'bg-emerald-600',
    accentColor: '#059669',
    packageName: 'org.neshan.nav',
    intentUrl: (q: string) =>
      `intent://navigate?q=${encodeURIComponent(q)}#Intent;scheme=nishan;package=org.neshan.nav;end;`,
    searchUrl: (q: string) => `https://neshan.org/maps/search/${encodeURIComponent(q)}`,
  },
  balad: {
    id: 'balad',
    nameFa: 'مسیریاب بلد',
    nameEn: 'Balad Navigation',
    iconBg: 'bg-blue-600',
    accentColor: '#2563eb',
    packageName: 'ir.balad.app',
    intentUrl: (q: string) =>
      `intent://navigation?q=${encodeURIComponent(q)}#Intent;scheme=balad;package=ir.balad.app;end;`,
    searchUrl: (q: string) => `https://balad.ir/search?q=${encodeURIComponent(q)}`,
  },
  'google-maps': {
    id: 'google-maps',
    nameFa: 'گوگل مپ',
    nameEn: 'Google Maps',
    iconBg: 'bg-red-600',
    accentColor: '#dc2626',
    packageName: 'com.google.android.apps.maps',
    intentUrl: (q: string) => `google.navigation:q=${encodeURIComponent(q)}`,
    searchUrl: (q: string) => `https://www.google.com/maps/search/${encodeURIComponent(q)}`,
  },
  waze: {
    id: 'waze',
    nameFa: 'مسیریاب ویز',
    nameEn: 'Waze GPS',
    iconBg: 'bg-sky-500',
    accentColor: '#0284c7',
    packageName: 'com.waze',
    intentUrl: (q: string) => `waze://?q=${encodeURIComponent(q)}&navigate=yes`,
    searchUrl: (q: string) => `https://waze.com/ul?q=${encodeURIComponent(q)}&navigate=yes`,
  },
};

export const NavigationAppView: React.FC<NavigationAppViewProps> = ({
  selectedAppId,
  currentSpeedKmH,
  speedLimitKmH,
  currentInstruction,
}) => {
  const [destinationSearch, setDestinationSearch] = useState('تهران - میدان آزادی');
  const [mapMode, setMapMode] = useState<'real-leaflet' | 'vector-ar'>('real-leaflet');
  const [userCoords, setUserCoords] = useState<[number, number]>([35.6997, 51.338]); // Default Azadi Square, Tehran
  const [gpsAcquired, setGpsAcquired] = useState(false);
  const [isLaunchingApp, setIsLaunchingApp] = useState(false);
  const [showLaunchNotice, setShowLaunchNotice] = useState(false);

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);

  const currentApp = NAV_APPS[selectedAppId] || NAV_APPS.neshan;
  const isSpeeding = currentSpeedKmH > speedLimitKmH;

  // Real GPS Geolocation Tracker
  useEffect(() => {
    if (!('geolocation' in navigator)) return;

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setUserCoords([lat, lng]);
        setGpsAcquired(true);

        if (mapInstanceRef.current && userMarkerRef.current) {
          userMarkerRef.current.setLatLng([lat, lng]);
          mapInstanceRef.current.panTo([lat, lng], { animate: true });
        }
      },
      (err) => {
        console.warn('GPS location access fallback:', err.message);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 }
    );

    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  // Initialize Leaflet Interactive Map
  useEffect(() => {
    if (mapMode !== 'real-leaflet' || !mapContainerRef.current) return;

    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    const map = L.map(mapContainerRef.current, {
      center: userCoords,
      zoom: 15,
      zoomControl: false,
    });

    // Dark style tile layer (CartoDB Dark Matter / Voyager)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap & CartoDB',
      maxZoom: 19,
    }).addTo(map);

    // Custom pulse marker for user vehicle
    const userIcon = L.divIcon({
      className: 'custom-vehicle-marker',
      html: `
        <div style="position: relative; width: 32px; height: 32px; display: flex; items-center; justify-content: center;">
          <div style="position: absolute; width: 32px; height: 32px; border-radius: 50%; background-color: ${currentApp.accentColor}; opacity: 0.4; animation: ping 1.5s infinite;"></div>
          <div style="width: 20px; height: 20px; border-radius: 50%; background-color: ${currentApp.accentColor}; border: 3px solid white; box-shadow: 0 4px 12px rgba(0,0,0,0.6); display: flex; items-center; justify-content: center;">
            <div style="width: 6px; height: 6px; border-radius: 50%; background: white;"></div>
          </div>
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
    });

    const marker = L.marker(userCoords, { icon: userIcon }).addTo(map);
    userMarkerRef.current = marker;
    mapInstanceRef.current = map;

    // Invalidate size after mount to prevent grey box tiles
    setTimeout(() => {
      map.invalidateSize();
    }, 300);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, [mapMode, selectedAppId]);

  // Direct Android Native Application Launcher
  const handleLaunchMobileApp = () => {
    setIsLaunchingApp(true);
    setShowLaunchNotice(true);

    const intentUri = currentApp.intentUrl(destinationSearch);
    const webFallbackUrl = currentApp.searchUrl(destinationSearch);

    // 1. Direct browser location redirection to trigger Native Android Intent / URI Protocol directly
    window.location.href = intentUri;

    // 2. Secondary fallback if browser blocks protocol or app is opened on web
    setTimeout(() => {
      window.open(webFallbackUrl, '_blank');
      setIsLaunchingApp(false);
    }, 1200);

    setTimeout(() => {
      setShowLaunchNotice(false);
    }, 5000);
  };

  return (
    <div className="relative w-full h-full bg-slate-950 overflow-hidden flex flex-col border-b border-slate-800">
      {/* Navigation Header Bar with App Title & Direct Launch Button */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-950/95 backdrop-blur border-b border-slate-800 z-20 text-xs">
        <div className="flex items-center gap-2">
          <div className={`w-6 h-6 rounded-lg ${currentApp.iconBg} flex items-center justify-center text-white shadow`}>
            <Navigation className="w-3.5 h-3.5 transform -rotate-45" />
          </div>
          <div className="flex flex-col">
            <span className="font-extrabold text-slate-100 text-xs">{currentApp.nameFa}</span>
            <span className="text-[9px] text-emerald-400 font-mono">
              {gpsAcquired ? '📍 GPS زنده متصل است' : 'نقشه هوشمند و مسیریابی'}
            </span>
          </div>
        </div>

        {/* Action Button: Directly Launch Native Installed Android App */}
        <button
          onClick={handleLaunchMobileApp}
          className={`px-3 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all shadow-lg ${
            isLaunchingApp
              ? 'bg-emerald-400 text-slate-950 scale-95'
              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/30'
          }`}
          title="اجرای مستقیم اپلیکیشن نصب‌شده روی گوشی اندروید"
        >
          <Smartphone className="w-4 h-4" />
          <span>اجرای مستقیم نرم‌افزار ({currentApp.nameFa.replace('مسیریاب ', '')})</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Main Map Body Area */}
      <div className="relative flex-1 w-full bg-slate-950 overflow-hidden">
        {/* Real Leaflet Map Container */}
        {mapMode === 'real-leaflet' && (
          <div ref={mapContainerRef} className="absolute inset-0 w-full h-full z-0" />
        )}

        {/* Vector Simulated Route Overlay Map */}
        {mapMode === 'vector-ar' && (
          <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="0.5" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            <path d="M 500 480 C 480 350, 250 250, 320 120 T 550 -50" fill="none" stroke="#059669" strokeWidth="20" />
            <g transform="translate(490, 340)">
              <circle r="20" fill="#10b981" fillOpacity="0.3" className="animate-ping" />
              <circle r="12" fill="#047857" stroke="#ffffff" strokeWidth="3" />
            </g>
          </svg>
        )}

        {/* Top Overlay: Search Bar */}
        <div className="absolute top-2 right-2 left-2 z-10 flex items-center gap-2">
          <div className="flex-1 flex items-center bg-slate-900/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/80 shadow-lg text-xs">
            <Search className="w-4 h-4 text-emerald-400 ml-2 flex-shrink-0" />
            <input
              type="text"
              value={destinationSearch}
              onChange={(e) => setDestinationSearch(e.target.value)}
              placeholder="جستجوی مقصد..."
              className="bg-transparent text-slate-100 placeholder-slate-400 focus:outline-none w-full text-xs"
            />
          </div>
          <button
            onClick={handleLaunchMobileApp}
            className="bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 backdrop-blur-md shadow"
          >
            <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">اجرای Native App</span>
          </button>
        </div>

        {/* Native App Launch Notice Banner */}
        {showLaunchNotice && (
          <div className="absolute top-12 right-2 left-2 z-30 bg-emerald-950 border-2 border-emerald-400 p-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-emerald-200 text-xs animate-bounce">
            <Check className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <div>
              <span className="font-black text-white block">در حال فراخوانی برنامه نیتیو ({currentApp.nameFa})...</span>
              <span className="text-[10px] text-emerald-300">
                فرمان اجرای Intent مستقیم به سیستم‌عامل اندروید ارسال شد.
              </span>
            </div>
          </div>
        )}

        {/* Turn-by-Turn Guidance Banner */}
        <div className="absolute top-14 right-2 left-2 z-10 bg-slate-950/95 border border-emerald-500/40 p-2.5 rounded-xl shadow-2xl flex items-center justify-between backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shadow-lg flex-shrink-0">
              <Navigation className="w-5 h-5 transform rotate-45" />
            </div>
            <div className="flex flex-col">
              <span className="text-emerald-400 text-[10px] font-bold">راهنمای مسیر آنلاین</span>
              <span className="text-slate-100 font-extrabold text-xs">{currentInstruction}</span>
            </div>
          </div>
          <div className="text-left flex flex-col items-end">
            <span className="text-slate-400 text-[9px]">فاصله</span>
            <span className="text-emerald-400 font-extrabold text-xs font-mono">۲۵۰ متر</span>
          </div>
        </div>

        {/* Speed Limit & GPS Speedometer Overlay (Bottom Right) */}
        <div className="absolute bottom-2 right-2 z-10 flex items-center gap-2">
          {/* Speed Limit Sign */}
          <div className="w-11 h-11 rounded-full bg-white border-4 border-red-600 flex flex-col items-center justify-center shadow-lg text-slate-950 font-black">
            <span className="text-[8px] text-red-600 font-bold leading-none">مجاز</span>
            <span className="text-sm font-extrabold leading-none">{speedLimitKmH}</span>
          </div>

          {/* Current Speedometer */}
          <div
            className={`px-3 py-1 rounded-2xl border backdrop-blur-md flex flex-col items-center shadow-xl ${
              isSpeeding
                ? 'bg-red-950/90 border-red-600 text-red-400 animate-pulse'
                : 'bg-slate-950/90 border-emerald-500/40 text-emerald-400'
            }`}
          >
            <span className="text-[9px] text-slate-400 font-medium">سرعت GPS</span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-black font-mono leading-none">{currentSpeedKmH}</span>
              <span className="text-[9px] font-bold">km/h</span>
            </div>
          </div>
        </div>

        {/* Map View Mode Switcher (Bottom Left) */}
        <div className="absolute bottom-2 left-2 z-10 flex items-center gap-1">
          <button
            onClick={() => setMapMode(mapMode === 'real-leaflet' ? 'vector-ar' : 'real-leaflet')}
            className="bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 px-2 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 backdrop-blur-md shadow"
          >
            <Compass className="w-3.5 h-3.5 text-emerald-400" />
            <span>{mapMode === 'real-leaflet' ? 'تغییر به نمای AR' : 'تغییر به نقشه زنده Leaflet'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
