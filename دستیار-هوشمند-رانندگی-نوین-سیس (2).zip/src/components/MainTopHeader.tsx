import React from 'react';
import {
  Power,
  Settings,
  Info,
  Camera,
  Zap,
  Play,
  Pause,
  Video,
} from 'lucide-react';
import { AppLayoutMode, BluetoothDeviceState } from '../types';

interface MainTopHeaderProps {
  layoutMode: AppLayoutMode;
  onChangeLayoutMode: (mode: AppLayoutMode) => void;
  nightVision: boolean;
  onToggleNightVision: () => void;
  onOpenSettings: () => void;
  onOpenAbout: () => void;
  onOpenGallery: () => void;
  onPowerOff: () => void;
  snapshotCount: number;
  bluetoothState: BluetoothDeviceState;
  currentSpeedKmH: number;
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
  musicTrackTitle: string;
  speedBoostLevel: string;
  hasDualCameraHardware: boolean;
}

export const MainTopHeader: React.FC<MainTopHeaderProps> = ({
  onOpenSettings,
  onOpenAbout,
  onOpenGallery,
  onPowerOff,
  snapshotCount,
  isMusicPlaying,
  onToggleMusic,
  musicTrackTitle,
  hasDualCameraHardware,
}) => {
  return (
    <header className="w-full bg-slate-950 border-b border-slate-800 px-3 py-1.5 flex items-center justify-between text-xs z-30 gap-2 flex-nowrap overflow-x-auto scrollbar-none">
      {/* Brand Title, Clips/Gallery, & Hardware Camera Status */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <div className="w-7 h-7 rounded-xl bg-emerald-600 text-slate-950 flex items-center justify-center font-black shadow">
          <Zap className="w-4 h-4 fill-slate-950" />
        </div>
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-200">
          <span>نوین سیس AI Drive</span>
        </div>

        {/* Camera Hardware Capability Status Badge */}
        <div
          className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 border ${
            hasDualCameraHardware
              ? 'bg-emerald-950/80 border-emerald-700 text-emerald-300'
              : 'bg-slate-900 border-slate-700 text-slate-300'
          }`}
          title={
            hasDualCameraHardware
              ? 'سخت‌افزار گوشی از فعال بودن ۲ دوربین همزمان پشتیبانی می‌کند.'
              : 'نمایش هوشمند دوربین با انتخاب کاربر'
          }
        >
          <Video className="w-3 h-3 text-emerald-400" />
          <span className="hidden sm:inline">
            {hasDualCameraHardware ? 'پشتیبانی ۲ دوربین همزمان 🟢' : 'دوربین فعال 🟢'}
          </span>
        </div>
      </div>

      {/* Header Inline Actions: Music, Settings, About, Power Off */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        {/* Music Player Mini */}
        <button
          onClick={onToggleMusic}
          className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 px-2 py-1 rounded-xl border border-slate-800 text-slate-300 text-[11px]"
          title={musicTrackTitle}
        >
          {isMusicPlaying ? (
            <Pause className="w-3.5 h-3.5 text-emerald-400" />
          ) : (
            <Play className="w-3.5 h-3.5 text-emerald-400" />
          )}
          <span className="hidden md:inline text-[10px] max-w-[80px] truncate">{musicTrackTitle}</span>
        </button>

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors flex items-center justify-center"
          title="تنظیمات سیستم (تغییر حالت کادرها و دوربین‌ها)"
        >
          <Settings className="w-4 h-4 text-emerald-400" />
        </button>

        {/* About Button */}
        <button
          onClick={onOpenAbout}
          className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors"
          title="درباره نوین سیس"
        >
          <Info className="w-4 h-4 text-amber-400" />
        </button>

        {/* Power Off Button */}
        <button
          onClick={onPowerOff}
          className="p-1.5 rounded-xl bg-red-950/80 hover:bg-red-600 text-red-400 hover:text-white border border-red-800 transition-colors flex items-center gap-1"
          title="خاموش کردن دستیار"
        >
          <Power className="w-4 h-4" />
          <span className="hidden md:inline text-[11px] font-bold">خاموش</span>
        </button>
      </div>
    </header>
  );
};

