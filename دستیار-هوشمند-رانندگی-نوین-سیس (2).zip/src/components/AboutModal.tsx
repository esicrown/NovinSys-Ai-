import React from 'react';
import { X, ShieldCheck, Award, Cpu, UserCheck, Eye, Sparkles } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-slate-900 border border-emerald-500/40 rounded-2xl shadow-2xl overflow-hidden text-slate-100">
        {/* Header background banner */}
        <div className="relative p-5 bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 border-b border-slate-800 text-center">
          <button
            onClick={onClose}
            className="absolute top-3 left-3 p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 rounded-2xl bg-emerald-500 text-slate-950 mx-auto flex items-center justify-center font-black shadow-xl shadow-emerald-500/30 mb-2">
            <Cpu className="w-8 h-8" />
          </div>

          <h2 className="text-lg font-black text-emerald-400">دستیار هوشمند ناوبری و ایمنی راننده</h2>
          <p className="text-xs text-slate-300 font-medium mt-0.5">سامانه پیشرفته بینایی ماشین و هوش مصنوعی جاده</p>
        </div>

        {/* Modal Content */}
        <div className="p-5 space-y-4 text-xs">
          {/* Required Company & Manager Credit Banner */}
          <div className="bg-emerald-950/80 border-2 border-emerald-500/60 p-4 rounded-2xl shadow-lg space-y-2 text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500 text-slate-950 rounded-full font-black text-xs">
              <Award className="w-4 h-4" />
              <span>مجری پروژه و مالکیت فکری</span>
            </div>

            <div className="space-y-1 text-slate-100 pt-1">
              <div className="text-base font-extrabold text-white">
                طراحی و اجرا: <span className="text-emerald-400 font-black">شرکت نوین سیس</span>
              </div>
              <div className="text-sm font-bold text-slate-200">
                مدیر شرکت: <span className="text-amber-400 font-black">ایثار شاقوزایی</span>
              </div>
            </div>
          </div>

          {/* Features bullet list */}
          <div className="space-y-2 text-slate-300 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
            <span className="font-extrabold text-emerald-400 text-xs block">
              💡 امکانات برجسته سیستم هوشمند نوین سیس:
            </span>
            <ul className="space-y-1.5 text-[11px] list-disc list-inside text-slate-300">
              <li>پایش مداوم چهره راننده و هشدار خواب‌آلودگی غیرقابل قطع صوتی.</li>
              <li>تشخیص خودکار خطوط جاده و انحراف از مسیر.</li>
              <li>فاصله‌سنجی هوشمند خودرو جلو (FCW) و زدن فلش هشدار در خطر برخورد.</li>
              <li>شناسایی دقیق حیوانات خارج از جاده به‌ویژه <strong className="text-amber-400">شتر</strong> در فواصل مختلف.</li>
              <li>خوانش صوتی تابلوهای راهنمایی و پیچ‌های جاده به زبان فارسی.</li>
              <li>فیلتر تصحیح تصویر دید در شب (Night Vision mode).</li>
              <li>تنظیم هوشمند ولوم موزیک بر اساس سرعت GPS (افزایش در سرعت ۹۰ و ۱۳۰ km/h).</li>
              <li>پاسخ‌دهی خودکار تماس پس از ۳ ثانیه فقط در صورت اتصال به بلوتوث خودرو.</li>
            </ul>
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-400 border-t border-slate-800 pt-3">
            <span>نسخه نرم‌افزار: v3.5 (نسخه تولید نوین سیس)</span>
            <span>طراحی شده برای اندروید & وب</span>
          </div>
        </div>
      </div>
    </div>
  );
};
