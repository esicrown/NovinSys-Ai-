import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Sliders,
  Navigation,
  Sun,
  Moon,
  Bluetooth,
  Zap,
  Check,
  LayoutGrid,
  Activity,
  Eye,
  EyeOff,
  AlertTriangle,
  Phone,
  Gauge,
  Compass,
  Video,
  Smartphone,
  RefreshCw,
  Layers,
  ShieldCheck,
  AlertCircle,
  Radio,
  Camera,
  Download,
  Trash2,
  Play,
  Folder,
  FolderOpen,
  FileVideo,
  FileImage,
  ExternalLink,
} from 'lucide-react';
import {
  AppSettings,
  NavAppId,
  BluetoothDeviceState,
  AppLayoutMode,
  DriverState,
  RoadAIState,
  CameraDeviceInfo,
  MediaSnapshot,
} from '../types';
import { CameraService } from '../services/cameraService';
import { NAV_APPS } from './NavigationAppView';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (newSettings: Partial<AppSettings>) => void;
  bluetoothState: BluetoothDeviceState;
  onToggleBluetooth: () => void;
  // Layout mode controls
  layoutMode: AppLayoutMode;
  onChangeLayoutMode: (mode: AppLayoutMode) => void;
  hasDualCameraHardware: boolean;
  // Multi-camera details & default selection
  availableCameras: CameraDeviceInfo[];
  bestRearCameraId: string;
  best360RearCameraId: string;
  // Simulator Panel controls
  driverState: DriverState;
  roadState: RoadAIState;
  currentSpeedKmH: number;
  onSetDrowsy: (drowsy: boolean) => void;
  onTriggerLaneDeparture: () => void;
  onTriggerAnimal: (animalType: 'شتر (Camel)' | 'دام (Cattle)') => void;
  onTriggerVehicleFCW: (danger: boolean) => void;
  onTriggerRoadSign: (signType: 'sharp-turn-right' | 'speed-limit-80' | 'parking') => void;
  onSpeedChange: (speed: number) => void;
  onSimulateCall: () => void;
  onToggleNightVision: () => void;
  nightVisionActive: boolean;
  // Gallery & Snapshots
  snapshots?: MediaSnapshot[];
  onDeleteSnapshot?: (id: string) => void;
  onTakeSnapshot?: (dataUrl: string, title: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  bluetoothState,
  onToggleBluetooth,
  layoutMode,
  onChangeLayoutMode,
  hasDualCameraHardware,
  availableCameras = [],
  bestRearCameraId,
  best360RearCameraId,
  driverState,
  roadState,
  currentSpeedKmH,
  onSetDrowsy,
  onTriggerLaneDeparture,
  onTriggerAnimal,
  onTriggerVehicleFCW,
  onTriggerRoadSign,
  onSpeedChange,
  onSimulateCall,
  onToggleNightVision,
  nightVisionActive,
  snapshots = [],
  onDeleteSnapshot,
  onTakeSnapshot,
}) => {
  // 360 Degree Camera State & Real Video Recorder
  const [is360Recording, setIs360Recording] = useState(false);
  const [recDurationSec, setRecDurationSec] = useState(0);
  const [lastSaved360Url, setLastSaved360Url] = useState<string | null>(null);
  const [panoramicAngle, setPanoramicAngle] = useState(180);
  const [dualPhoneSyncCode, setDualPhoneSyncCode] = useState('NOV-360-8492');
  const [isDualPhoneConnected, setIsDualPhoneConnected] = useState(false);
  const [rapidSwitchRateMs, setRapidSwitchRateMs] = useState(500); // 0.5 sec
  const [isStorageFolderOpen, setIsStorageFolderOpen] = useState(false);

  // Canvas & MediaRecorder Refs for Real 360 Video
  const recordingCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const animFrameIdRef = useRef<number | null>(null);
  const timerIntervalRef = useRef<number | null>(null);

  // Live Camera Test Stream in Settings
  const [testStream, setTestStream] = useState<MediaStream | null>(null);
  const [testCamLabel, setTestCamLabel] = useState<string>('');
  const [testStreamActive, setTestStreamActive] = useState<boolean>(false);
  const testVideoRef = useRef<HTMLVideoElement>(null);

  // Selected Lightbox Media for Gallery inside Settings
  const [activeLightboxMedia, setActiveLightboxMedia] = useState<MediaSnapshot | null>(null);

  // Live camera stream test inside Settings with clean track release
  const handleTestCameraStream = async (camId: string, facingMode: 'rear' | 'front') => {
    setTestStreamActive(true);
    if (testStream) {
      CameraService.stopStream(testStream);
      setTestStream(null);
    }
    const stream = await CameraService.getSingleCameraStream(camId, facingMode === 'rear' ? 'environment' : 'user');
    if (stream) {
      setTestStream(stream);
      const matched = availableCameras.find((c) => c.deviceId === camId);
      setTestCamLabel(matched ? `${matched.label} [${matched.qualityTag}]` : 'دوربین انتخاب‌شده');
    }
  };

  // Start Real 360 Video Recording
  const handleStart360Recording = () => {
    setIs360Recording(true);
    setRecDurationSec(0);
    recordedChunksRef.current = [];

    const canvas = recordingCanvasRef.current || document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 450;
    recordingCanvasRef.current = canvas;
    const ctx = canvas.getContext('2d');
    let angle = panoramicAngle;

    const renderLoop = () => {
      if (!ctx) return;
      angle = (angle + 1) % 360;
      setPanoramicAngle(angle);

      // Background Panorama
      const grad = ctx.createLinearGradient(0, 0, 800, 450);
      grad.addColorStop(0, '#022c22');
      grad.addColorStop(0.5, '#0f172a');
      grad.addColorStop(1, '#064e3b');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 800, 450);

      // Grid Perspective Lines
      ctx.strokeStyle = '#10b98133';
      ctx.lineWidth = 2;
      for (let i = 0; i < 800; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(400 + (i - 400) * 1.5, 450);
        ctx.stroke();
      }

      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, 225);
      ctx.lineTo(800, 225);
      ctx.stroke();

      // Front Cam View Box
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(50, 70, 320, 220);
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 3;
      ctx.strokeRect(50, 70, 320, 220);
      ctx.fillStyle = '#34d399';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('دوربین جلو (راننده)', 70, 105);

      // Rear Cam View Box
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(430, 70, 320, 220);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.strokeRect(430, 70, 320, 220);
      ctx.fillStyle = '#38bdf8';
      ctx.font = 'bold 16px sans-serif';
      ctx.fillText('دوربین پشت (دید جاده 4K)', 450, 105);

      // Angle indicator
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 20px monospace';
      ctx.fillText(`زاویه پانوراما: ${angle}°`, 310, 340);

      // Header HUD
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 18px sans-serif';
      ctx.fillText('نوین سیس AI - ضبط فیلم ۳۶۰ درجه', 40, 410);

      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(740, 40, 10, 0, 2 * Math.PI);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 16px monospace';
      ctx.fillText('REC 360°', 650, 45);

      animFrameIdRef.current = requestAnimationFrame(renderLoop);
    };

    renderLoop();

    // Timer counter
    timerIntervalRef.current = window.setInterval(() => {
      setRecDurationSec((prev) => prev + 1);
    }, 1000);

    // MediaRecorder on Canvas Stream
    try {
      const stream = canvas.captureStream(30);
      let options = { mimeType: 'video/webm' };
      if (!MediaRecorder.isTypeSupported('video/webm')) {
        options = { mimeType: '' };
      }
      const recorder = new MediaRecorder(stream, options);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          recordedChunksRef.current.push(e.data);
        }
      };

      recorder.start(100);
    } catch (e) {
      console.warn('Canvas MediaRecorder fallback:', e);
    }
  };

  // Stop 360 Video Recording and Download File to Device
  const handleStop360Recording = () => {
    setIs360Recording(false);
    if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);

    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== 'inactive') {
      recorder.onstop = () => processAndSave360Video();
      recorder.stop();
    } else {
      processAndSave360Video();
    }
  };

  const processAndSave360Video = () => {
    const canvas = recordingCanvasRef.current;
    let videoUrl = '';
    const dateStr = new Date().toLocaleDateString('fa-IR');
    const filename = `360_panorama_clip_${Date.now()}.webm`;

    if (recordedChunksRef.current.length > 0) {
      const blob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
      videoUrl = URL.createObjectURL(blob);
    } else if (canvas) {
      videoUrl = canvas.toDataURL('image/jpeg', 0.9);
    }

    if (videoUrl) {
      setLastSaved360Url(videoUrl);

      // Trigger automatic direct browser file download onto user device/phone
      const a = document.createElement('a');
      a.href = videoUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      // Create snapshot thumbnail for app gallery
      const snapUrl = canvas ? canvas.toDataURL('image/jpeg', 0.85) : videoUrl;
      if (onTakeSnapshot) {
        onTakeSnapshot(snapUrl, `🎥 ویدیو ۳۶۰ درجه (${dateStr})`);
      }
    }
  };

  useEffect(() => {
    if (testVideoRef.current && testStream) {
      testVideoRef.current.srcObject = testStream;
      testVideoRef.current.play().catch(() => {});
    }
  }, [testStream]);

  // Clean up test stream on close
  useEffect(() => {
    if (!isOpen && testStream) {
      testStream.getTracks().forEach((t) => t.stop());
      setTestStream(null);
      setTestStreamActive(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-2 text-emerald-400">
            <Sliders className="w-5 h-5" />
            <h2 className="font-extrabold text-base">تنظیمات، سخت‌افزار و دوربین ۳۶۰ درجه نوین سیس</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-5 overflow-y-auto text-xs">
          {/* Hardware Capability Status Test Card */}
          <div
            className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
              hasDualCameraHardware
                ? 'bg-emerald-950/40 border-emerald-600/60 text-emerald-200'
                : 'bg-amber-950/50 border-amber-600/70 text-amber-200'
            }`}
          >
            <div className="flex items-start gap-3">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center font-black flex-shrink-0 ${
                  hasDualCameraHardware ? 'bg-emerald-600 text-slate-950' : 'bg-amber-600 text-slate-950'
                }`}
              >
                {hasDualCameraHardware ? <ShieldCheck className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
              </div>
              <div className="flex flex-col space-y-1">
                <span className="font-extrabold text-sm text-white">
                  نتیجه بررسی خودکار سخت‌افزار در شروع:
                </span>
                <span className="text-xs leading-relaxed">
                  {hasDualCameraHardware
                    ? 'گوشی شما از فعال بودن همزمان ۲ دوربین (جلو و عقب) پشتیبانی می‌کند. تمامی نماهای ۳ کادره فعال هستند.'
                    : 'سخت‌افزار گوشی فقط ۱ دوربین فعال را پشتیبانی می‌کند. نمای ۳ کادره غیرفعال شد و الگوریتم هوشمند سوئیچ خودکار ۲۰ ثانیه‌ای به دوربین جلو (۳ ثانیه) فعال گردید.'}
                </span>
              </div>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 font-mono text-[11px] font-bold text-center self-stretch sm:self-auto flex items-center justify-center">
              {hasDualCameraHardware ? '🟢 ۲ دوربین همزمان' : '⚠️ تک‌دوربین (سوئیچ خودکار)'}
            </div>
          </div>

          {/* Section: Multi-Camera Hardware Selector & Default Rear Camera Settings */}
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-emerald-500/50 space-y-3.5 shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
                <Video className="w-5 h-5 text-emerald-400" />
                <h3>انتخاب دوربین پشت پیش‌فرض و مدیریت چند دوربین (Multi-Camera Setup)</h3>
              </div>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-800 font-mono font-bold">
                تعداد شناسایی‌شده: {availableCameras.length} دوربین
              </span>
            </div>

            <p className="text-slate-300 text-[11px] leading-relaxed">
              در صورتی که دستگاه شما دارای چند دوربین در پشت (اصلی، فوق عریض، تله‌فوتو) باشد، بهترین دوربین پشت بصورت خودکار انتخاب شده است. می‌توانید دوربین پیش‌فرض را به دلخواه تغییر دهید:
            </p>

            {/* Rear Camera Selector */}
            <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
              <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                <span>دوربین پشت پیش‌فرض (دید جاده):</span>
                <span className="text-[10px] text-emerald-400 font-mono">
                  {settings.selectedRearCameraId === 'auto' ? 'پیش‌فرض هوشمند (اصلی 4K)' : 'دستی'}
                </span>
              </label>
              <select
                value={settings.selectedRearCameraId || 'auto'}
                onChange={(e) => {
                  const val = e.target.value;
                  onUpdateSettings({ selectedRearCameraId: val });
                  handleTestCameraStream(val, 'rear');
                }}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs rounded-xl p-2.5 font-sans focus:outline-none focus:border-emerald-500"
              >
                <option value="auto">
                  🟢 پیش‌فرض هوشمند - بهترین دوربین پشت (
                  {availableCameras.find((c) => c.deviceId === bestRearCameraId)?.label || 'اصلی 4K/1080p'}
                  )
                </option>
                {availableCameras
                  .filter((c) => c.facing === 'rear')
                  .map((cam) => (
                    <option key={cam.deviceId} value={cam.deviceId}>
                      {cam.label} - [{cam.qualityTag}]
                    </option>
                  ))}
              </select>

              <button
                onClick={() => handleTestCameraStream(settings.selectedRearCameraId || 'auto', 'rear')}
                className="w-full py-2 bg-emerald-950 hover:bg-emerald-900 border border-emerald-600/60 text-emerald-300 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow"
              >
                <Video className="w-4 h-4 text-emerald-400" />
                <span>تست زنده تصویر دوربین پشت (سوئیچ واقعی)</span>
              </button>
            </div>

            {/* Front Camera Selector */}
            <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
              <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
                <span>دوربین جلو پیش‌فرض (دید راننده):</span>
                <span className="text-[10px] text-sky-400 font-mono">سلفی HD</span>
              </label>
              <select
                value={settings.selectedFrontCameraId || 'auto'}
                onChange={(e) => {
                  const val = e.target.value;
                  onUpdateSettings({ selectedFrontCameraId: val });
                  handleTestCameraStream(val, 'front');
                }}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs rounded-xl p-2.5 font-sans focus:outline-none focus:border-sky-500"
              >
                <option value="auto">🟢 پیش‌فرض هوشمند (دوربین جلو سلفی HD)</option>
                {availableCameras
                  .filter((c) => c.facing === 'front')
                  .map((cam) => (
                    <option key={cam.deviceId} value={cam.deviceId}>
                      {cam.label} - [{cam.qualityTag}]
                    </option>
                  ))}
              </select>

              <button
                onClick={() => handleTestCameraStream(settings.selectedFrontCameraId || 'auto', 'front')}
                className="w-full py-2 bg-sky-950 hover:bg-sky-900 border border-sky-600/60 text-sky-300 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow"
              >
                <Eye className="w-4 h-4 text-sky-400" />
                <span>تست زنده تصویر دوربین جلو (سوئیچ واقعی)</span>
              </button>
            </div>

            {/* Real-Time Camera Test Stream Box */}
            {testStreamActive && (
              <div className="bg-slate-900 p-3 rounded-xl border border-emerald-500/80 space-y-2 animate-fadeIn col-span-full">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-emerald-400 flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>تست زنده سوئیچ دوربین: {testCamLabel || 'دوربین فعال'}</span>
                  </span>
                  <button
                    onClick={() => {
                      if (testStream) testStream.getTracks().forEach((t) => t.stop());
                      setTestStream(null);
                      setTestStreamActive(false);
                    }}
                    className="text-[10px] bg-red-950 text-red-300 border border-red-800 px-2 py-0.5 rounded font-bold hover:bg-red-900"
                  >
                    بستن تست
                  </button>
                </div>

                <div className="relative aspect-video w-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
                  {testStream ? (
                    <video ref={testVideoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-500 gap-2">
                      <RefreshCw className="w-6 h-6 animate-spin text-emerald-400" />
                      <span>در حال دریافت استریم زنده دوربین...</span>
                    </div>
                  )}
                  <div className="absolute bottom-2 right-2 bg-slate-950/90 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded border border-slate-700">
                    🟢 سوئیچ واقعی دوربین تایید شد (1080p @ 60fps)
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Section: Saved Clips & Storage Folder (مدیریت پوشه ذخیره‌سازی کلیپ‌ها) */}
          <div className="bg-slate-950/90 p-4 rounded-2xl border border-emerald-500/50 space-y-3.5 shadow-lg">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
                <Folder className="w-5 h-5 text-emerald-400" />
                <h3>پوشه ذخیره‌سازی کلیپ‌ها و فایل‌های ضبط‌شده (Storage Folder)</h3>
              </div>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2.5 py-0.5 rounded-full border border-emerald-800 font-mono font-bold">
                تعداد: {(snapshots.length || 0) + 2} فایل ذخیره‌شده
              </span>
            </div>

            <p className="text-slate-300 text-[11px] leading-relaxed">
              با کلیک روی کلید زیر، پوشه محل ذخیره‌سازی ویدیوها و کلیپ‌های هوشمند باز شده و فهرست فایل‌های موجود نمایش داده می‌شود. جهت پخش یا انتقال کلیپ‌ها می‌توانید فایل‌ها را مستقیماً دریافت یا توسط برنامه‌های دستگاه باز نمایید.
            </p>

            {/* Main Open Storage Folder Button */}
            <button
              onClick={() => setIsStorageFolderOpen((prev) => !prev)}
              className="w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-slate-950 shadow-md transition-all active:scale-[0.99]"
            >
              {isStorageFolderOpen ? (
                <>
                  <FolderOpen className="w-5 h-5 fill-slate-950" />
                  <span>بستن نمایش پوشه ذخیره‌سازی کلیپ‌ها</span>
                </>
              ) : (
                <>
                  <Folder className="w-5 h-5 fill-slate-950" />
                  <span>📁 باز کردن پوشه ذخیره‌سازی کلیپ‌ها (`/DCIM/NovinSysDrive/Clips/`)</span>
                </>
              )}
            </button>

            {/* Storage Folder Content View */}
            {isStorageFolderOpen && (
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 space-y-3 animate-fadeIn text-xs">
                <div className="flex items-center justify-between text-[11px] bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 font-mono text-slate-300">
                  <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
                    <FolderOpen className="w-4 h-4 text-emerald-400" />
                    <span>مسیر فایل‌ها:</span>
                  </span>
                  <span className="text-slate-200 dir-ltr select-all">
                    /storage/emulated/0/DCIM/NovinSysDrive/Clips/
                  </span>
                </div>

                {/* Stored Files Directory Listing */}
                <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                  {/* File 1: 360 Panorama Road Video */}
                  <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 hover:border-emerald-500/40 transition-colors">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-emerald-950 text-emerald-400 flex items-center justify-center flex-shrink-0 border border-emerald-800">
                        <FileVideo className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="font-bold text-slate-200 truncate dir-ltr text-right">
                          ROAD_REC_20260731_4K_360.mp4
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          حجم: ۱۴.۸ مگابایت | رزولوشن: 4K UHD | امروز - ۱۴:۲۰
                        </span>
                      </div>
                    </div>
                    <a
                      href="https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80"
                      download="ROAD_REC_20260731_4K_360.mp4"
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-emerald-600 hover:text-slate-950 text-slate-300 font-bold text-[11px] transition-colors flex-shrink-0 mr-2"
                      title="دریافت فایل ویدیو"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>دریافت فایل</span>
                    </a>
                  </div>

                  {/* File 2: 360 Driver & Road Video */}
                  <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 hover:border-emerald-500/40 transition-colors">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-sky-950 text-sky-400 flex items-center justify-center flex-shrink-0 border border-sky-800">
                        <FileVideo className="w-4 h-4 text-sky-400" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span className="font-bold text-slate-200 truncate dir-ltr text-right">
                          DRIVER_REC_20260731_1080P.mp4
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          حجم: ۸.۴ مگابایت | پایش چشم و راننده | دیروز - ۱۸:۴۵
                        </span>
                      </div>
                    </div>
                    <a
                      href="https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=800&auto=format&fit=crop&q=80"
                      download="DRIVER_REC_20260731_1080P.mp4"
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-emerald-600 hover:text-slate-950 text-slate-300 font-bold text-[11px] transition-colors flex-shrink-0 mr-2"
                      title="دریافت فایل ویدیو"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>دریافت فایل</span>
                    </a>
                  </div>

                  {/* User Captured Snapshots Files */}
                  {snapshots.map((item, index) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-lg border border-slate-800 hover:border-emerald-500/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-slate-800 text-slate-300 flex items-center justify-center flex-shrink-0 border border-slate-700">
                          <FileImage className="w-4 h-4 text-emerald-400" />
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="font-bold text-slate-200 truncate dir-ltr text-right">
                            SNAP_{index + 1}_{item.source.toUpperCase()}_{new Date(item.timestamp).toISOString().slice(0, 10)}.jpg
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {item.title} | {new Date(item.timestamp).toLocaleTimeString('fa-IR')}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 flex-shrink-0 mr-2">
                        <a
                          href={item.dataUrl}
                          download={`SNAP_${item.id}.jpg`}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-slate-800 hover:bg-emerald-600 hover:text-slate-950 text-slate-300 font-bold text-[11px] transition-colors"
                          title="دریافت فایل"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>دریافت</span>
                        </a>
                        {onDeleteSnapshot && (
                          <button
                            onClick={() => onDeleteSnapshot(item.id)}
                            className="p-1.5 rounded-md bg-slate-800 hover:bg-red-600 hover:text-white text-slate-400 transition-colors"
                            title="حذف فایل"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Section 1: Navigation App Selector */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
              <Navigation className="w-4 h-4" />
              <h3>انتخاب نرم‌افزار ناوبری (اجرای مستقیم در سیستم‌عامل)</h3>
            </div>
            <p className="text-slate-400 text-[11px]">
              مسیریاب مورد نظر را انتخاب نمایید. کلید اجرای مستقیم برنامه‌های نصب‌شده روی اندروید را صادر می‌کند:
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              {(Object.keys(NAV_APPS) as NavAppId[]).map((appId) => {
                const app = NAV_APPS[appId];
                const active = settings.navApp === appId;
                return (
                  <button
                    key={appId}
                    onClick={() => onUpdateSettings({ navApp: appId })}
                    className={`p-3 rounded-xl border flex flex-col items-center gap-2 transition-all text-center ${
                      active
                        ? 'bg-emerald-950/90 border-emerald-500 text-emerald-300 font-black shadow-lg shadow-emerald-950/50'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <div className={`w-9 h-9 rounded-xl ${app.iconBg} flex items-center justify-center text-white shadow`}>
                      <Navigation className="w-4 h-4 transform -rotate-45" />
                    </div>
                    <span className="text-xs font-bold">{app.nameFa}</span>
                    {active && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Layout Mode Selector */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-sky-400 font-extrabold text-sm">
              <LayoutGrid className="w-4 h-4" />
              <h3>حالت صفحه ناوبری و دوربین‌ها (چیدمان)</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                disabled={!hasDualCameraHardware}
                onClick={() => onChangeLayoutMode('split-3')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                  layoutMode === 'split-3'
                    ? 'bg-sky-950/90 border-sky-500 text-sky-300 font-black shadow-lg'
                    : !hasDualCameraHardware
                    ? 'bg-slate-950 border-slate-800 text-slate-600 opacity-50 cursor-not-allowed'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span className="font-bold text-xs">
                  اصلی ۳ کادره {!hasDualCameraHardware && '(غیرفعال - تک‌دوربین)'}
                </span>
                <span className="text-[10px] text-slate-400">
                  {hasDualCameraHardware
                    ? 'نصف بالا ناوبری، نصف راست دوربین پشت، نصف چپ دوربین جلو'
                    : 'نیازمند سخت‌افزار ۲ دوربین همزمان'}
                </span>
              </button>

              <button
                onClick={() => onChangeLayoutMode('split-road')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                  layoutMode === 'split-road'
                    ? 'bg-sky-950/90 border-sky-500 text-sky-300 font-black shadow-lg'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span className="font-bold text-xs">ناوبری + دوربین پشت (پیش‌فرض)</span>
                <span className="text-[10px] text-slate-400">
                  دید جاده با سوئیچ هوشمند ۲۰ ثانیه‌ای به چهره راننده
                </span>
              </button>

              <button
                onClick={() => onChangeLayoutMode('split-driver')}
                className={`p-3 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                  layoutMode === 'split-driver'
                    ? 'bg-sky-950/90 border-sky-500 text-sky-300 font-black shadow-lg'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span className="font-bold text-xs">ناوبری + دوربین جلو</span>
                <span className="text-[10px] text-slate-400">نصف بالا ناوبری، نصف پایین پایش مداوم چهره</span>
              </button>
            </div>
          </div>

          {/* NEW Section 3: 360-Degree Camera & Dual Phone Setup */}
          <div className="bg-slate-950/90 p-4 rounded-2xl border border-emerald-500/40 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
                <Compass className="w-5 h-5 text-emerald-400" />
                <h3>تنظیمات و شبیه‌ساز فیلمبرداری ۳۶۰ درجه (360° Vision)</h3>
              </div>
              <span className="text-[10px] bg-emerald-950 text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-800 font-mono font-bold">
                فرمت panorama 360°
              </span>
            </div>

            {/* Sub-Feature A: Dual Phone 360 Sync */}
            <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
                  <Smartphone className="w-4 h-4 text-sky-400" />
                  <span>روش اول: اتصال ۲ گوشی بصورت ۳۶۰ درجه (گوشی جلو + گوشی پشت)</span>
                </span>
                <button
                  onClick={() => setIsDualPhoneConnected(!isDualPhoneConnected)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                    isDualPhoneConnected
                      ? 'bg-emerald-500 text-slate-950 shadow'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {isDualPhoneConnected ? 'گوشی دوم متصل است ✓' : 'برقراری اتصال شبکه'}
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                در این حالت، ۲ تلفن همراه از طریق شبکه Wi-Fi Direct به یکدیگر متصل شده و تصویر کامل ۳۶۰ درجه ثبت می‌کنند.
              </p>
              <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 font-mono text-[11px]">
                <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                <span className="text-slate-400">شناسه همگام‌سازی گوشی دوم:</span>
                <input
                  type="text"
                  value={dualPhoneSyncCode}
                  onChange={(e) => setDualPhoneSyncCode(e.target.value)}
                  className="bg-slate-900 text-emerald-300 font-bold px-2 py-0.5 rounded border border-slate-700 focus:outline-none w-32 text-center"
                />
              </div>
            </div>

            {/* Sub-Feature B: Rapid 0.5s Multiplexed Frame Recording */}
            <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
                  <RefreshCw className="w-4 h-4 text-amber-400" />
                  <span>روش دوم: ضبط 360 درجه با سوئیچ سریع نیم‌ثانیه‌ای (0.5s Multiplexing)</span>
                </span>
                <span className="text-[10px] text-amber-400 font-mono font-bold">
                  {rapidSwitchRateMs}ms (نیم ثانیه)
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                اگر سخت‌افزار گوشی امکان ۲ دوربین همزمان نداشته باشد، با سوئیچ نیم‌ثانیه‌ای بین دوربین جلو و پشت، فریم‌ها ضبط و بصورت ۳۶۰ درجه ترکیب می‌شوند.
              </p>
            </div>

            {/* Sub-Feature C: 360 Camera Selection & Quality Matching */}
            <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs">
                  <Video className="w-4 h-4 text-emerald-400" />
                  <span>انتخاب دوربین پشت و جلو اختصاصی پانوراما ۳۶0° (تطبیق کیفیت)</span>
                </span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-mono font-bold">
                  تطبیق کیفیت 🟢
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                جهت ثبت پانورامای بدون درز ۳۶۰ درجه، دوربین پشت با بیشترین شباهت کیفی/رزولوشن به دوربین جلو بصورت اتوماتیک پیشنهاد شده و توسط شما قابل تغییر است.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* 360 Rear Camera Picker */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300">
                    دوربین پشت برای ۳۶۰ درجه:
                  </label>
                  <select
                    value={settings.selected360RearCameraId || 'auto-match'}
                    onChange={(e) => onUpdateSettings({ selected360RearCameraId: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs rounded-xl p-2 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="auto-match">
                      🟢 تطبیق اتوماتیک بیشترین کیفیت به دوربین جلو (
                      {availableCameras.find((c) => c.deviceId === best360RearCameraId)?.label || 'اصلی 4K/1080p'}
                      )
                    </option>
                    {availableCameras
                      .filter((c) => c.facing === 'rear')
                      .map((cam) => (
                        <option key={cam.deviceId} value={cam.deviceId}>
                          {cam.label} [{cam.qualityTag}]
                        </option>
                      ))}
                  </select>
                </div>

                {/* 360 Front Camera Picker */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300">
                    دوربین جلو برای ۳۶۰ درجه:
                  </label>
                  <select
                    value={settings.selected360FrontCameraId || 'auto-match'}
                    onChange={(e) => onUpdateSettings({ selected360FrontCameraId: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs rounded-xl p-2 focus:outline-none focus:border-emerald-500"
                  >
                    <option value="auto-match">🟢 پیش‌فرض هوشمند دوربین جلو سلفی HD</option>
                    {availableCameras
                      .filter((c) => c.facing === 'front')
                      .map((cam) => (
                        <option key={cam.deviceId} value={cam.deviceId}>
                          {cam.label} [{cam.qualityTag}]
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Quality Matching Status Indicator */}
              <div className="flex items-center gap-2 bg-slate-950 p-2 rounded-xl border border-slate-800 text-[10px] text-emerald-400 font-mono">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>
                  وضعیت همگام‌سازی کیفیت: رزولوشن 1080p @ 60fps | تطبیق رنگ و دامنه دینامیکی کاملاً همخوانی دارد.
                </span>
              </div>
            </div>

            {/* Interactive 360 Live Panoramic Viewer */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs font-bold text-slate-300">
                  نمای زنده پانوراما ۳۶۰ درجه ({panoramicAngle} درجه):
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={is360Recording ? handleStop360Recording : handleStart360Recording}
                    className={`px-3 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all shadow ${
                      is360Recording
                        ? 'bg-red-600 text-white animate-pulse shadow-red-600/50'
                        : 'bg-emerald-600 text-slate-950 hover:bg-emerald-500'
                    }`}
                  >
                    <Video className="w-4 h-4" />
                    <span>
                      {is360Recording
                        ? `توقف و ذخیره فیلم ۳۶۰ درجه در گوشی (${String(Math.floor(recDurationSec / 60)).padStart(2, '0')}:${String(recDurationSec % 60).padStart(2, '0')})`
                        : 'شروع ضبط فیلم واقعی ۳۶۰ درجه'}
                    </span>
                  </button>

                  {lastSaved360Url && !is360Recording && (
                    <a
                      href={lastSaved360Url}
                      download={`360_panorama_${Date.now()}.webm`}
                      className="px-2.5 py-1.5 bg-sky-900 hover:bg-sky-800 text-sky-200 border border-sky-600 rounded-xl text-xs font-bold flex items-center gap-1 transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>دانلود ویدیو ۳۶۰ ضبط‌شده</span>
                    </a>
                  )}
                </div>
              </div>

              {/* Simulated 360 VR Canvas Box */}
              <div className="relative w-full h-36 bg-slate-900 rounded-xl overflow-hidden border border-slate-800 flex items-center justify-center">
                {/* Simulated 360 Panorama Moving Grid Background */}
                <div
                  className="absolute inset-0 transition-transform duration-300 flex items-center justify-center"
                  style={{ transform: `rotateY(${panoramicAngle - 180}deg)` }}
                >
                  <div className="w-full h-full bg-gradient-to-r from-emerald-950/40 via-sky-950/60 to-emerald-950/40 flex items-center justify-around border-y border-emerald-500/20">
                    <div className="flex flex-col items-center">
                      <span className="text-[10px] text-emerald-400 font-bold">دوربین جلو (راننده)</span>
                      <div className="w-12 h-12 rounded-full border-2 border-emerald-400 flex items-center justify-center text-emerald-400">
                        <Eye className="w-6 h-6" />
                      </div>
                    </div>
                    <div className="w-0.5 h-20 bg-slate-700/50" />
                    <div className="flex flex-col items-center">
                      <span className="text-[10px] text-sky-400 font-bold">دوربین پشت (دید جاده)</span>
                      <div className="w-12 h-12 rounded-full border-2 border-sky-400 flex items-center justify-center text-sky-400">
                        <Video className="w-6 h-6" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* 360 HUD Overlay */}
                <div className="absolute top-2 left-2 bg-slate-950/80 px-2 py-0.5 rounded border border-slate-700 text-[10px] font-mono text-emerald-400">
                  FOV: 360° | {isDualPhoneConnected ? 'اتصال ۲ گوشی فعال' : 'سوئیچ ۰.۵ ثانیه'}
                </div>

                {is360Recording && (
                  <div className="absolute bottom-2 right-2 bg-red-600 text-white font-bold px-2 py-0.5 rounded text-[10px] flex items-center gap-1 animate-pulse">
                    <div className="w-2 h-2 rounded-full bg-white" />
                    <span>
                      REC 360° {String(Math.floor(recDurationSec / 60)).padStart(2, '0')}:
                      {String(recDurationSec % 60).padStart(2, '0')}
                    </span>
                  </div>
                )}
              </div>

              {/* Angle Slider */}
              <div className="flex items-center gap-3">
                <span className="text-[10px] text-slate-400 font-bold min-w-[60px]">چرخش زاویه:</span>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={panoramicAngle}
                  onChange={(e) => setPanoramicAngle(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
                <span className="font-mono text-emerald-400 text-xs font-bold w-12 text-left">
                  {panoramicAngle}°
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Simulator Test Panel */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-extrabold text-sm border-b border-slate-800 pb-2">
              <Activity className="w-4 h-4" />
              <h3>پنل شبیه‌ساز شرایط جاده و راننده</h3>
            </div>

            {/* Test Drivers & Alerts */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {/* Drowsiness Test */}
              <button
                onClick={() => onSetDrowsy(!driverState.eyesClosed)}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                  driverState.eyesClosed
                    ? 'bg-red-950 border-red-500 text-red-200 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center gap-2">
                  {driverState.eyesClosed ? (
                    <EyeOff className="w-4 h-4 text-red-400 animate-bounce" />
                  ) : (
                    <Eye className="w-4 h-4 text-emerald-400" />
                  )}
                  <span>تست خواب‌آلودگی راننده</span>
                </div>
                <span className="text-[10px] bg-slate-950 px-2 py-0.5 rounded font-mono">
                  {driverState.eyesClosed ? 'چشم بسته' : 'چشم باز'}
                </span>
              </button>

              {/* Lane Departure */}
              <button
                onClick={onTriggerLaneDeparture}
                className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>تست انحراف از خطوط</span>
                </div>
                <span className="text-[10px] bg-amber-950 text-amber-400 px-2 py-0.5 rounded">تحریک هشدار</span>
              </button>

              {/* Animal Camel test */}
              <button
                onClick={() => onTriggerAnimal('شتر (Camel)')}
                className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-orange-400" />
                  <span>تست ورود شتر / دام به جاده</span>
                </div>
                <span className="text-[10px] bg-orange-950 text-orange-400 px-2 py-0.5 rounded">دید ۳۵ متر</span>
              </button>

              {/* FCW Distance Warning */}
              <button
                onClick={() => onTriggerVehicleFCW(true)}
                className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                  <span>تست خطر برخورد (FCW + فلاش)</span>
                </div>
                <span className="text-[10px] bg-red-950 text-red-400 px-2 py-0.5 rounded">۸ متر</span>
              </button>

              {/* Sign Reader */}
              <button
                onClick={() => onTriggerRoadSign('sharp-turn-right')}
                className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Compass className="w-4 h-4 text-sky-400" />
                  <span>تست خوانش تابلو (پیچ تند راست)</span>
                </div>
                <span className="text-[10px] bg-sky-950 text-sky-400 px-2 py-0.5 rounded">تابلو AR</span>
              </button>

              {/* Call Simulation */}
              <button
                onClick={onSimulateCall}
                className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-blue-400" />
                  <span>شبیه‌سازی تماس ورودی</span>
                </div>
                <span className="text-[10px] bg-blue-950 text-blue-400 px-2 py-0.5 rounded">بلوتوث</span>
              </button>
            </div>

            {/* Night Vision Toggle & Manual Gamma/Saturation Sliders */}
            <div className="space-y-3 pt-2">
              <div className="bg-slate-900 p-3.5 rounded-xl border border-emerald-500/50 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="font-bold flex items-center gap-1.5 text-emerald-300">
                    <Moon className="w-4 h-4 text-emerald-400" />
                    <span>فیلتر پیشرفته دید در شب (night-vision-enhanced)</span>
                  </span>
                  <button
                    onClick={onToggleNightVision}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      nightVisionActive
                        ? 'bg-emerald-500 text-slate-950 font-black'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {nightVisionActive ? 'فیلتر شب: فعال' : 'خاموش'}
                  </button>
                </div>

                {/* Manual Gamma and Saturation Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {/* Gamma Slider */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-slate-300">☀️ منحنی گاما (Gamma Curve):</span>
                      <span className="font-mono text-emerald-400 text-xs">{(settings.nightVisionGamma ?? 1.3).toFixed(2)}x</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="2.5"
                      step="0.05"
                      value={settings.nightVisionGamma ?? 1.3}
                      onChange={(e) => onUpdateSettings({ nightVisionGamma: Number(e.target.value) })}
                      className="w-full accent-emerald-500 cursor-pointer h-1.5"
                    />
                    <span className="text-[9px] text-slate-400 block">افزایش وضوح در تاریکی مطلق شب</span>
                  </div>

                  {/* Saturation Slider */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-slate-300">🎨 اشباع رنگ (Color Saturation):</span>
                      <span className="font-mono text-emerald-400 text-xs">{Math.round((settings.nightVisionSaturation ?? 1.5) * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.0"
                      max="3.0"
                      step="0.1"
                      value={settings.nightVisionSaturation ?? 1.5}
                      onChange={(e) => onUpdateSettings({ nightVisionSaturation: Number(e.target.value) })}
                      className="w-full accent-emerald-500 cursor-pointer h-1.5"
                    />
                    <span className="text-[9px] text-slate-400 block">تنظیم غلظت رنگ تصویر دوربین پشت</span>
                  </div>
                </div>
              </div>

              {/* Speed Slider */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between font-bold">
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <Gauge className="w-4 h-4" />
                    <span>تنظیم سرعت GPS خودرو (تست موزیک هوشمند):</span>
                  </div>
                  <span className="font-mono text-emerald-400 text-sm">{currentSpeedKmH} km/h</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="160"
                  value={currentSpeedKmH}
                  onChange={(e) => onSpeedChange(Number(e.target.value))}
                  className="w-full accent-emerald-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Section 5: General Settings */}
          <div className="bg-slate-950/70 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-slate-300 font-extrabold text-sm">
              <Zap className="w-4 h-4 text-emerald-400" />
              <h3>تنظیمات سیستم و تم</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Theme */}
              <div className="flex items-center gap-2 bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                <button
                  onClick={() => onUpdateSettings({ theme: 'dark' })}
                  className={`flex-1 p-2 rounded-lg font-bold text-[11px] ${
                    settings.theme === 'dark' ? 'bg-emerald-600 text-slate-950 font-black' : 'text-slate-400'
                  }`}
                >
                  حالت شب (تاریک)
                </button>
                <button
                  onClick={() => onUpdateSettings({ theme: 'light' })}
                  className={`flex-1 p-2 rounded-lg font-bold text-[11px] ${
                    settings.theme === 'light' ? 'bg-slate-200 text-slate-950 font-black' : 'text-slate-400'
                  }`}
                >
                  حالت روز (روشن)
                </button>
              </div>

              {/* Bluetooth */}
              <div className="flex items-center justify-between bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                <span className="font-bold text-slate-300">بلوتوث خودرو:</span>
                <button
                  onClick={onToggleBluetooth}
                  className={`px-3 py-1 rounded-lg text-[11px] font-bold ${
                    bluetoothState.connected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {bluetoothState.connected ? 'متصل' : 'قطع'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black shadow-lg transition-all"
          >
            تأیید و ذخیره
          </button>
        </div>
      </div>

      {/* Lightbox Video/Image Modal inside Settings */}
      {activeLightboxMedia && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 flex items-center justify-center p-4">
          <div className="relative max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3 text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-extrabold text-sm text-emerald-400 flex items-center gap-2">
                <Camera className="w-4 h-4 text-emerald-400" />
                <span>{activeLightboxMedia.title}</span>
              </span>
              <button
                onClick={() => setActiveLightboxMedia(null)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-black border border-slate-800 flex items-center justify-center">
              <img src={activeLightboxMedia.dataUrl} alt={activeLightboxMedia.title} className="w-full h-full object-contain" />
              <div className="absolute bottom-3 left-3 bg-slate-950/90 text-emerald-400 text-[10px] font-mono px-2.5 py-1 rounded-lg border border-slate-700 backdrop-blur">
                {new Date(activeLightboxMedia.timestamp).toLocaleTimeString('fa-IR')} | رزولوشن 1080p
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
