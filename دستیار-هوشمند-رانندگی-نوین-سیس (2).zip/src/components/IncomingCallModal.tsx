import React, { useEffect, useState } from 'react';
import { Phone, PhoneOff, Bluetooth, ShieldAlert, Check } from 'lucide-react';
import { SimulatedCall, BluetoothDeviceState } from '../types';
import { audioAlertService } from '../services/audioAlertService';

interface IncomingCallModalProps {
  call: SimulatedCall | null;
  bluetoothState: BluetoothDeviceState;
  onAnswerCall: () => void;
  onRejectCall: () => void;
}

export const IncomingCallModal: React.FC<IncomingCallModalProps> = ({
  call,
  bluetoothState,
  onAnswerCall,
  onRejectCall,
}) => {
  const [countdown, setCountdown] = useState(3);

  useEffect(() => {
    if (!call || !call.active || call.status !== 'ringing') return;

    // If bluetooth is NOT connected, call is ignored and suppressed
    if (!bluetoothState.connected) {
      return;
    }

    // Bluetooth is connected -> start 3-second auto-answer countdown!
    audioAlertService.speakPersian(`تماس ورودی از ${call.callerName}. اتصال خودکار در ۳ ثانیه.`, true);
    setCountdown(3);

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onAnswerCall();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [call, bluetoothState, onAnswerCall]);

  if (!call || !call.active) return null;

  // If Bluetooth is NOT connected, suppress call representation
  if (!bluetoothState.connected && call.status === 'suppressed') {
    return (
      <div className="fixed top-14 left-4 z-40 bg-slate-900/90 border border-slate-700 text-slate-300 text-[10px] px-3 py-1.5 rounded-xl backdrop-blur shadow-lg flex items-center gap-2">
        <ShieldAlert className="w-4 h-4 text-amber-400" />
        <span>تماس ورودی به دلیل عدم اتصال به بلوتوث نادیده گرفته شد (حفظ تمرکز راننده)</span>
      </div>
    );
  }

  if (call.status === 'connected') {
    return (
      <div className="fixed top-14 left-2 right-2 max-w-md mx-auto z-40 bg-blue-950/95 border-2 border-blue-500 text-white p-3 rounded-2xl shadow-2xl backdrop-blur flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black animate-pulse">
            <Phone className="w-5 h-5" />
          </div>
          <div className="flex flex-col text-right text-xs">
            <span className="font-bold">تماس متصل شد (دست آزاد / بلوتوث)</span>
            <span className="text-[11px] text-blue-200">{call.callerName} ({call.phone})</span>
          </div>
        </div>
        <button
          onClick={onRejectCall}
          className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold text-xs flex items-center gap-1 shadow"
        >
          <PhoneOff className="w-3.5 h-3.5" />
          <span>قطع تماس</span>
        </button>
      </div>
    );
  }

  return (
    <div className="fixed top-14 left-2 right-2 max-w-md mx-auto z-50 bg-slate-950/95 border-2 border-emerald-500 text-white p-3.5 rounded-2xl shadow-2xl backdrop-blur animate-bounce flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black animate-ping">
          <Phone className="w-5 h-5" />
        </div>
        <div className="flex flex-col text-right">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-black text-emerald-400">تماس ورودی (بلوتوث خودرو)</span>
            <span className="bg-blue-600 text-white text-[9px] px-1.5 py-0.5 rounded font-bold">
              پاسخ خودکار: {countdown} ثانیه
            </span>
          </div>
          <span className="text-sm font-extrabold">{call.callerName}</span>
          <span className="text-[10px] text-slate-400">{call.phone}</span>
        </div>
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={onAnswerCall}
          className="p-2 bg-emerald-600 hover:bg-emerald-500 text-slate-950 rounded-xl font-bold shadow transition-transform hover:scale-105"
          title="پاسخ مستقیم"
        >
          <Phone className="w-4 h-4" />
        </button>
        <button
          onClick={onRejectCall}
          className="p-2 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold shadow transition-transform hover:scale-105"
          title="رد تماس"
        >
          <PhoneOff className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
