import React from 'react';
import { Sliders, Eye, EyeOff, AlertTriangle, Car, Flame, Gauge, Moon, PhoneCall, ChevronUp, ChevronDown, CheckCircle2 } from 'lucide-react';
import { DriverState, RoadAIState } from '../types';

interface SimulatorControlPanelProps {
  driverState: DriverState;
  roadState: RoadAIState;
  currentSpeedKmH: number;
  isOpen: boolean;
  onToggleOpen: () => void;
  onSetDrowsy: (drowsy: boolean) => void;
  onTriggerLaneDeparture: () => void;
  onTriggerAnimal: (animalType: 'شتر (Camel)' | 'دام (Cattle)') => void;
  onTriggerVehicleFCW: (danger: boolean) => void;
  onTriggerRoadSign: (signType: 'sharp-turn-right' | 'speed-limit-80' | 'parking') => void;
  onSpeedChange: (speed: number) => void;
  onSimulateCall: () => void;
  onToggleNightVision: () => void;
  nightVisionActive: boolean;
}

export const SimulatorControlPanel: React.FC<SimulatorControlPanelProps> = ({
  driverState,
  roadState,
  currentSpeedKmH,
  isOpen,
  onToggleOpen,
  onSetDrowsy,
  onTriggerLaneDeparture,
  onTriggerAnimal,
  onTriggerVehicleFCW,
  onTriggerRoadSign,
  onSpeedChange,
  onSimulateCall,
  onToggleNightVision,
  nightVisionActive,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 border-t border-slate-800 shadow-2xl transition-all">
      {/* Drawer Toggle Header */}
      <button
        onClick={onToggleOpen}
        className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-850 flex items-center justify-between text-xs font-bold text-slate-200 border-b border-slate-800/60"
      >
        <div className="flex items-center gap-2 text-emerald-400">
          <Sliders className="w-4 h-4" />
          <span>پانل شبیه‌ساز شرایط رانندگی (تست هوش مصنوعی و سنسورها)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded-full">
            تغییر وضعیت چهره، سرعت و خطوط
          </span>
          {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
        </div>
      </button>

      {/* Expanded Controls Drawer */}
      {isOpen && (
        <div className="p-3 max-h-72 overflow-y-auto grid grid-cols-1 md:grid-cols-4 gap-3 text-xs bg-slate-950">
          {/* Section 1: Driver Drowsiness */}
          <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 flex flex-col gap-2">
            <span className="font-bold text-slate-300 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>پایش چهره راننده</span>
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => onSetDrowsy(false)}
                className={`py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 text-[11px] ${
                  !driverState.eyesClosed
                    ? 'bg-emerald-600 text-slate-950 shadow'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>چشم باز (عادی)</span>
              </button>
              <button
                onClick={() => onSetDrowsy(true)}
                className={`py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 text-[11px] ${
                  driverState.eyesClosed
                    ? 'bg-red-600 text-white shadow animate-pulse'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <EyeOff className="w-3.5 h-3.5" />
                <span>چشم بسته (خواب)</span>
              </button>
            </div>
            <span className="text-[10px] text-slate-400">
              * خواب‌آلودگی آژیر بلند با شدت بالا فعال می‌کند که فقط با باز شدن چشم قطع می‌شود.
            </span>
          </div>

          {/* Section 2: Road AI & Animals */}
          <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 flex flex-col gap-2">
            <span className="font-bold text-slate-300 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>مخاطرات جاده & حیوانات</span>
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => onTriggerAnimal('شتر (Camel)')}
                className="py-1.5 px-2 rounded-lg font-bold bg-amber-950 text-amber-400 border border-amber-800 hover:bg-amber-900 text-[11px] flex items-center justify-center gap-1"
              >
                <span>🐪 تشخیص شتر</span>
              </button>
              <button
                onClick={onTriggerLaneDeparture}
                className="py-1.5 px-2 rounded-lg font-bold bg-slate-800 text-slate-200 hover:bg-slate-700 text-[11px] flex items-center justify-center gap-1"
              >
                <span>⚠️ انحراف خطوط</span>
              </button>
              <button
                onClick={() => onTriggerVehicleFCW(true)}
                className="py-1.5 px-2 rounded-lg font-bold bg-red-950 text-red-400 border border-red-800 hover:bg-red-900 text-[11px] flex items-center justify-center gap-1 col-span-2"
              >
                <Car className="w-3.5 h-3.5" />
                <span>برخورد نزدیک با خودرو (FCW + فلش)</span>
              </button>
            </div>
          </div>

          {/* Section 3: Road Signs & Night Vision */}
          <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 flex flex-col gap-2">
            <span className="font-bold text-slate-300 flex items-center gap-1.5">
              <Moon className="w-4 h-4 text-sky-400" />
              <span>خوانش تابلوها & دید در شب</span>
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => onTriggerRoadSign('sharp-turn-right')}
                className="py-1.5 px-2 rounded-lg font-bold bg-slate-800 text-slate-200 hover:bg-slate-700 text-[11px]"
              >
                <span>↩️ پیچ به راست</span>
              </button>
              <button
                onClick={() => onTriggerRoadSign('speed-limit-80')}
                className="py-1.5 px-2 rounded-lg font-bold bg-slate-800 text-slate-200 hover:bg-slate-700 text-[11px]"
              >
                <span>🛑 تابلو ۸۰km/h</span>
              </button>
              <button
                onClick={onToggleNightVision}
                className={`py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 text-[11px] col-span-2 ${
                  nightVisionActive
                    ? 'bg-emerald-600 text-slate-950 font-black'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Moon className="w-3.5 h-3.5" />
                <span>{nightVisionActive ? 'فیلتر شب: فعال' : 'فعال‌سازی فیلتر تصویر شب'}</span>
              </button>
            </div>
          </div>

          {/* Section 4: GPS Speed Slider & Call Sim */}
          <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <Gauge className="w-4 h-4 text-emerald-400" />
                <span>سرعت خودرو (GPS)</span>
              </span>
              <span className="font-mono font-black text-emerald-400 text-xs">{currentSpeedKmH} km/h</span>
            </div>
            <input
              type="range"
              min="0"
              max="150"
              step="5"
              value={currentSpeedKmH}
              onChange={(e) => onSpeedChange(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex items-center justify-between text-[10px] text-slate-400">
              <span>0 (ایست)</span>
              <span className="text-amber-400 font-bold">90+ (افزایش ۱۰ ولوم)</span>
              <span className="text-red-400 font-bold">130+ (افزایش ۲۰ ولوم)</span>
            </div>
            <button
              onClick={onSimulateCall}
              className="py-1 px-2 rounded-lg font-bold bg-blue-950 text-blue-400 border border-blue-800 hover:bg-blue-900 text-[11px] flex items-center justify-center gap-1 mt-1"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>تست تماس ورودی (بلوتوث)</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
