export type AppLayoutMode = 'split-3' | 'split-driver' | 'split-road' | 'nav-only' | 'cams-only';

export type NavAppId = 'neshan' | 'balad' | 'google-maps' | 'waze';

export interface NavAppConfig {
  id: NavAppId;
  nameFa: string;
  nameEn: string;
  iconBg: string;
  accentColor: string;
  logoSvgUrl?: string;
}

export type AlertType =
  | 'drowsiness'
  | 'lane-departure'
  | 'overspeed'
  | 'fcw'
  | 'animal'
  | 'pedestrian'
  | 'road-sign'
  | 'speed-boost';

export interface AlertItem {
  id: string;
  type: AlertType;
  title: string;
  message: string;
  timestamp: number;
  severity: 'danger' | 'warning' | 'info';
  persistentUntilEyeOpen?: boolean;
  durationMs?: number;
}

export interface DriverState {
  eyesClosed: boolean;
  drowsy: boolean;
  fatigueScore: number; // 0 - 100
  yawning: boolean;
  headTilted: boolean;
}

export interface DetectedVehicle {
  id: string;
  distanceMeters: number;
  speedKmH: number;
  xPct: number; // 0-100 percentage inside frame
  yPct: number;
  widthPct: number;
  heightPct: number;
  dangerLevel: 'safe' | 'caution' | 'danger';
}

export interface DetectedAnimal {
  id: string;
  type: 'شتر (Camel)' | 'دام (Cattle)' | 'حیوان وحشی (Wildlife)';
  distanceMeters: number;
  xPct: number;
  yPct: number;
  widthPct: number;
  heightPct: number;
}

export interface DetectedPedestrian {
  id: string;
  distanceMeters: number;
  xPct: number;
  yPct: number;
  widthPct?: number;
  heightPct?: number;
  dangerLevel?: 'safe' | 'warning' | 'danger';
}

export type SignType =
  | 'sharp-turn-right'
  | 'sharp-turn-left'
  | 'speed-limit-80'
  | 'speed-limit-110'
  | 'parking'
  | 'steep-down'
  | 'danger-zone';

export interface RoadSignInfo {
  id: string;
  type: SignType;
  titleFa: string;
  distanceMeters: number;
  iconName: string;
}

export interface RoadAIState {
  lanesVisible: boolean;
  laneOffset: number; // -100 to +100 (- left, + right)
  laneDepartureWarning: boolean;
  vehicles: DetectedVehicle[];
  animals: DetectedAnimal[];
  pedestrians: DetectedPedestrian[];
  detectedSign: RoadSignInfo | null;
  speedLimitKmH: number;
}

export interface MediaSnapshot {
  id: string;
  source: 'driver' | 'road';
  timestamp: number;
  dataUrl: string;
  title: string;
}

export interface AudioTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  durationStr: string;
  audioUrl?: string;
}

export interface CameraDeviceInfo {
  deviceId: string;
  label: string;
  facing: 'front' | 'rear' | 'external';
  isPrimaryRear?: boolean;
  qualityTag?: string;
}

export interface AppSettings {
  theme: 'dark' | 'light';
  navApp: NavAppId;
  bluetoothAutoAnswer: boolean;
  suppressCallsWithoutBt: boolean;
  smartMusicEnabled: boolean;
  selectedMusicFolder: string;
  nightVisionAuto: boolean;
  nightVisionManual: boolean;
  drowsinessSensitivity: 'high' | 'medium' | 'low';
  fcwSensitivity: 'high' | 'medium' | 'low';
  voiceAlertsEnabled: boolean;
  flashEmergencyTrigger: boolean;
  keepScreenAwake: boolean;
  selectedRearCameraId: string;
  selectedFrontCameraId: string;
  selected360RearCameraId: string;
  selected360FrontCameraId: string;
  nightVisionGamma: number; // 0.5 to 2.5 (default 1.3)
  nightVisionSaturation: number; // 0.0 to 3.0 (default 1.5)
}

export interface BluetoothDeviceState {
  connected: boolean;
  deviceName: string;
  batteryPct: number;
}

export interface SimulatedCall {
  callerName: string;
  phone: string;
  active: boolean;
  autoAnswerTimerSec?: number;
  status: 'ringing' | 'connected' | 'suppressed' | 'ended';
}
