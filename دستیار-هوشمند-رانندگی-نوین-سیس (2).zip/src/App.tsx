import React, { useState, useEffect, useCallback } from 'react';
import {
  AppLayoutMode,
  AppSettings,
  DriverState,
  RoadAIState,
  AlertItem,
  MediaSnapshot,
  BluetoothDeviceState,
  SimulatedCall,
  NavAppId,
  CameraDeviceInfo,
} from './types';
import { audioAlertService } from './services/audioAlertService';
import { CameraService } from './services/cameraService';
import { musicPlayerService } from './services/musicPlayerService';

import { MainTopHeader } from './components/MainTopHeader';
import { NavigationAppView } from './components/NavigationAppView';
import { DriverCameraView } from './components/DriverCameraView';
import { RoadCameraView } from './components/RoadCameraView';
import { AlertBannerOverlay } from './components/AlertBannerOverlay';
import { SimulatorControlPanel } from './components/SimulatorControlPanel';
import { SettingsModal } from './components/SettingsModal';
import { AboutModal } from './components/AboutModal';
import { GalleryModal } from './components/GalleryModal';
import { IncomingCallModal } from './components/IncomingCallModal';
import { Power, RotateCcw, Clock, RefreshCw } from 'lucide-react';

export default function App() {
  // Application Mode & Power State
  const [layoutMode, setLayoutMode] = useState<AppLayoutMode>('split-3');
  const [isAppPoweredOff, setIsAppPoweredOff] = useState<boolean>(false);

  // Hardware Camera Capability & Enumeration State
  const [hasDualCameraHardware, setHasDualCameraHardware] = useState<boolean>(true);
  const [availableCameras, setAvailableCameras] = useState<CameraDeviceInfo[]>([]);
  const [bestRearCameraId, setBestRearCameraId] = useState<string>('auto');
  const [best360RearCameraId, setBest360RearCameraId] = useState<string>('auto-match');

  // Modals state
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(true);

  // App Settings
  const [settings, setSettings] = useState<AppSettings>({
    theme: 'dark',
    navApp: 'neshan',
    bluetoothAutoAnswer: true,
    suppressCallsWithoutBt: true,
    smartMusicEnabled: true,
    selectedMusicFolder: '/Music/NovinSysDrive',
    nightVisionAuto: false,
    nightVisionManual: false,
    drowsinessSensitivity: 'high',
    fcwSensitivity: 'high',
    voiceAlertsEnabled: true,
    flashEmergencyTrigger: true,
    keepScreenAwake: true,
    selectedRearCameraId: 'auto',
    selectedFrontCameraId: 'auto',
    selected360RearCameraId: 'auto-match',
    selected360FrontCameraId: 'auto-match',
    nightVisionGamma: 1.3,
    nightVisionSaturation: 1.5,
  });

  // Bluetooth State
  const [bluetoothState, setBluetoothState] = useState<BluetoothDeviceState>({
    connected: true,
    deviceName: 'سیستم صوتی خودرو (BT_CAR)',
    batteryPct: 92,
  });

  // Simulated Call
  const [simulatedCall, setSimulatedCall] = useState<SimulatedCall | null>(null);

  // Night Vision Mode State
  const [nightVision, setNightVision] = useState(false);

  // Driving & GPS Speed State
  const [currentSpeedKmH, setCurrentSpeedKmH] = useState(65);
  const [speedLimitKmH, setSpeedLimitKmH] = useState(80);
  const [navInstruction, setNavInstruction] = useState('۲۰۰ متر بعد: پیچ به راست به سمت بلوار آزادی');

  // Active Alerts
  const [activeAlert, setActiveAlert] = useState<AlertItem | null>(null);
  const [isEmergencyStrobe, setIsEmergencyStrobe] = useState(false);

  // Driver Face Monitoring State
  const [driverState, setDriverState] = useState<DriverState>({
    eyesClosed: false,
    drowsy: false,
    fatigueScore: 18,
    yawning: false,
    headTilted: false,
  });

  // Road AI Vision State
  const [roadState, setRoadState] = useState<RoadAIState>({
    lanesVisible: true,
    laneOffset: 0,
    laneDepartureWarning: false,
    vehicles: [
      { id: 'v1', distanceMeters: 45, speedKmH: 60, xPct: 42, yPct: 46, widthPct: 18, heightPct: 24, dangerLevel: 'safe' },
    ],
    animals: [],
    pedestrians: [],
    detectedSign: null,
    speedLimitKmH: 80,
  });

  // Camera Web Streams
  const [driverCamStream, setDriverCamStream] = useState<MediaStream | null>(null);
  const [roadCamStream, setRoadCamStream] = useState<MediaStream | null>(null);

  // Captured Snapshots Gallery
  const [snapshots, setSnapshots] = useState<MediaSnapshot[]>([]);

  // Music Player State
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [musicTrackTitle, setMusicTrackTitle] = useState('جاده و آرامش - نوین سیس');
  const [speedBoostLevel, setSpeedBoostLevel] = useState('none');

  // Automated 30s Rear Road Camera -> Front Driver Eye Inspection Duty Cycle in split-road mode
  const [splitRoadSubMode, setSplitRoadSubMode] = useState<'road' | 'driver'>('road');
  const [splitRoadSecLeft, setSplitRoadSecLeft] = useState<number>(30);

  useEffect(() => {
    const isSplitRoadActive = layoutMode === 'split-road' || (layoutMode === 'split-3' && !hasDualCameraHardware);

    if (!isSplitRoadActive) {
      setSplitRoadSubMode('road');
      setSplitRoadSecLeft(30);
      return;
    }

    const timer = setInterval(() => {
      setSplitRoadSecLeft((prevSec) => {
        if (splitRoadSubMode === 'road') {
          // In rear road camera mode: count down 30 seconds
          if (prevSec <= 1) {
            setSplitRoadSubMode('driver');
            return 3; // Start driver camera eye inspection (minimum 3 seconds)
          }
          return prevSec - 1;
        } else {
          // In front driver camera mode: inspect eyes
          if (driverState.eyesClosed) {
            // Eyes are closed/drowsy! Hold on front camera until eyes are confirmed open
            return 3;
          } else {
            // Eyes confirmed open! Once 3s inspection completes, return to road mode
            if (prevSec <= 1) {
              setSplitRoadSubMode('road');
              return 30; // Reset to 30 seconds for rear road camera
            }
            return prevSec - 1;
          }
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [layoutMode, hasDualCameraHardware, splitRoadSubMode, driverState.eyesClosed]);

  // Initialize Web Camera Streams & Enforce Strict Mutual Exclusion per Layout Mode
  useEffect(() => {
    let isMounted = true;
    async function syncCameraStreams() {
      const cams = await CameraService.getAvailableVideoDevices();
      if (!isMounted) return;
      setAvailableCameras(cams);

      // Mode 1: Front Driver Camera View ONLY
      if (layoutMode === 'split-driver') {
        if (roadCamStream) {
          CameraService.stopStream(roadCamStream);
          setRoadCamStream(null);
        }
        if (!driverCamStream) {
          const stream = await CameraService.getSingleCameraStream(
            settings.selectedFrontCameraId || 'auto',
            'user'
          );
          if (isMounted && stream) setDriverCamStream(stream);
        }
      }
      // Mode 2: Rear Road Camera View (with 10s Rear / 3s Front Eye Check cycle)
      else if (layoutMode === 'split-road' || (layoutMode === 'split-3' && !hasDualCameraHardware)) {
        if (splitRoadSubMode === 'driver') {
          if (roadCamStream && !hasDualCameraHardware) {
            CameraService.stopStream(roadCamStream);
            setRoadCamStream(null);
          }
          if (!driverCamStream) {
            const stream = await CameraService.getSingleCameraStream(
              settings.selectedFrontCameraId || 'auto',
              'user'
            );
            if (isMounted && stream) setDriverCamStream(stream);
          }
        } else {
          if (driverCamStream && !hasDualCameraHardware) {
            CameraService.stopStream(driverCamStream);
            setDriverCamStream(null);
          }
          if (!roadCamStream) {
            const stream = await CameraService.getSingleCameraStream(
              settings.selectedRearCameraId || 'auto',
              'environment'
            );
            if (isMounted && stream) setRoadCamStream(stream);
          }
        }
      }
      // Mode 3: Dual Camera Views (3-Split or Cams Only)
      else {
        const {
          driverStream,
          roadStream,
          hasSeparateCameras,
          bestRearCameraId: bestRear,
          best360RearCameraId: best360,
        } = await CameraService.getDualCameraStreams(
          settings.selectedRearCameraId,
          settings.selectedFrontCameraId
        );

        if (isMounted) {
          setHasDualCameraHardware(hasSeparateCameras);
          setBestRearCameraId(bestRear);
          setBest360RearCameraId(best360);

          if (hasSeparateCameras) {
            if (driverStream) setDriverCamStream(driverStream);
            if (roadStream) setRoadCamStream(roadStream);
          } else {
            // Hardware cannot run 2 cameras simultaneously! Fallback to split-road mode.
            if (driverCamStream) {
              CameraService.stopStream(driverCamStream);
              setDriverCamStream(null);
            }
            if (roadStream) setRoadCamStream(roadStream);
            setLayoutMode('split-road');
          }
        }
      }
    }

    syncCameraStreams();

    // Enable Keep Screen Awake if available
    if ('wakeLock' in navigator && settings.keepScreenAwake) {
      navigator.wakeLock.request('screen').catch(() => {});
    }

    return () => {
      isMounted = false;
    };
  }, [
    layoutMode,
    settings.keepScreenAwake,
    settings.selectedRearCameraId,
    settings.selectedFrontCameraId,
    splitRoadSubMode,
  ]);

  // Handle Drowsiness Eye State Trigger
  const handleToggleEyeState = useCallback(() => {
    setDriverState((prev) => {
      const nextClosed = !prev.eyesClosed;
      if (nextClosed) {
        // Driver eyes closed -> Start loud siren & continuous Persian voice alert
        audioAlertService.startDrowsinessSiren();
        setActiveAlert({
          id: 'drowsy-' + Date.now(),
          type: 'drowsiness',
          title: 'هشدار حیاتی خواب‌آلودگی راننده!',
          message: 'چشمان راننده بسته شده است! با صدای بلند بیدار شوید. (غیرقابل قطع با کلید ولوم تا زمان باز شدن چشم)',
          timestamp: Date.now(),
          severity: 'danger',
          durationMs: 999999,
        });
      } else {
        // Driver eyes opened -> Stop siren
        audioAlertService.stopDrowsinessSiren();
        setActiveAlert(null);
        audioAlertService.speakPersian('سطح هوشیاری تایید شد. رانندگی ایمن.');
      }

      return {
        ...prev,
        eyesClosed: nextClosed,
        drowsy: nextClosed,
        fatigueScore: nextClosed ? 92 : 18,
      };
    });
  }, []);

  // Set explicit Drowsy State
  const handleSetDrowsy = (drowsy: boolean) => {
    if (drowsy !== driverState.eyesClosed) {
      handleToggleEyeState();
    }
  };

  // Trigger Lane Departure Alert
  const handleTriggerLaneDeparture = () => {
    setRoadState((prev) => ({ ...prev, laneDepartureWarning: true }));
    audioAlertService.speakPersian('هشدار! انحراف از خطوط جاده! لطفا خودرو را بین خطوط هدایت کنید.');

    setActiveAlert({
      id: 'lane-' + Date.now(),
      type: 'lane-departure',
      title: 'هشدار انحراف از خطوط جاده',
      message: 'خودرو از خطوط وسط یا کنار جاده خارج شده است.',
      timestamp: Date.now(),
      severity: 'warning',
      durationMs: 10000,
    });

    setTimeout(() => {
      setRoadState((prev) => ({ ...prev, laneDepartureWarning: false }));
    }, 5000);
  };

  // Trigger Animal (Camel) Detection Alert
  const handleTriggerAnimal = (animalType: 'شتر (Camel)' | 'دام (Cattle)') => {
    setRoadState((prev) => ({
      ...prev,
      animals: [
        {
          id: 'anim-' + Date.now(),
          type: animalType,
          distanceMeters: 35,
          xPct: 65,
          yPct: 40,
          widthPct: 22,
          heightPct: 30,
        },
      ],
    }));

    audioAlertService.speakPersian(`هشدار! تشخیص حیوان ${animalType} در حاشیه جاده! سرعت را کاهش دهید.`);

    setActiveAlert({
      id: 'anim-' + Date.now(),
      type: 'animal',
      title: `هشدار ورود ${animalType} به مسیر`,
      message: `حضور ${animalType} در فاصله ۳۵ متری در حاشیه جاده شناسایی شد.`,
      timestamp: Date.now(),
      severity: 'warning',
      durationMs: 10000,
    });

    setTimeout(() => {
      setRoadState((prev) => ({ ...prev, animals: [] }));
    }, 8000);
  };

  // Trigger FCW Collision Danger + Phone Flash Strobe
  const handleTriggerVehicleFCW = (danger: boolean) => {
    setRoadState((prev) => ({
      ...prev,
      vehicles: [
        {
          id: 'v-close',
          distanceMeters: 8,
          speedKmH: 45,
          xPct: 35,
          yPct: 38,
          widthPct: 32,
          heightPct: 40,
          dangerLevel: danger ? 'danger' : 'safe',
        },
      ],
    }));

    if (danger) {
      setIsEmergencyStrobe(true);
      CameraService.pulseHardwareFlash(roadCamStream, 3000);

      audioAlertService.speakPersian('هشدار خطر برخورد! فاصله با خودروی جلو بسیار نزدیک است! ترمز کنید.');

      setActiveAlert({
        id: 'fcw-' + Date.now(),
        type: 'fcw',
        title: 'هشدار فاصله خطرناک (FCW)',
        message: 'فاصله تا خودروی جلویی کمتر از ۸ متر است! فلش هشدار فعال شد.',
        timestamp: Date.now(),
        severity: 'danger',
        durationMs: 10000,
      });

      setTimeout(() => {
        setIsEmergencyStrobe(false);
      }, 3000);
    }
  };

  // Trigger Road Sign Reader (Sharp Turn, Speed limit, Parking)
  const handleTriggerRoadSign = (signType: 'sharp-turn-right' | 'speed-limit-80' | 'parking') => {
    let signTitleFa = '';
    let speechMsg = '';

    if (signType === 'sharp-turn-right') {
      signTitleFa = 'پیچ تند به راست';
      speechMsg = 'هشدار جاده: پیچ تند به سمت راست در ۲۰۰ متری. سرعت خود را تنظیم کنید.';
      setNavInstruction('۲۰۰ متر بعد: پیچ تند به سمت راست');
    } else if (signType === 'speed-limit-80') {
      signTitleFa = 'سرعت مجاز ۸۰ کیلومتر';
      speechMsg = 'تابلو راهنمایی: بیشینه سرعت مجاز ۸۰ کیلومتر بر ساعت.';
      setSpeedLimitKmH(80);
    } else {
      signTitleFa = 'محل پارکینگ';
      speechMsg = 'تابلو راهنمایی: پارکینگ مجاز استراحت رانندگان در ۵۰۰ متری.';
    }

    setRoadState((prev) => ({
      ...prev,
      detectedSign: {
        id: 'sign-' + Date.now(),
        type: signType,
        titleFa: signTitleFa,
        distanceMeters: 200,
        iconName: 'Navigation2',
      },
    }));

    audioAlertService.speakPersian(speechMsg);

    setActiveAlert({
      id: 'sign-' + Date.now(),
      type: 'road-sign',
      title: `خوانش تابلو: ${signTitleFa}`,
      message: speechMsg,
      timestamp: Date.now(),
      severity: 'info',
      durationMs: 10000,
    });
  };

  // Handle GPS Speed Slider Change
  const handleSpeedChange = (newSpeed: number) => {
    setCurrentSpeedKmH(newSpeed);

    const result = musicPlayerService.updateVolumeForSpeed(newSpeed, settings.smartMusicEnabled);
    setSpeedBoostLevel(result.level);

    if (result.boostChanged) {
      if (result.level === 'boost130') {
        audioAlertService.speakPersian(
          'هشدار! سرعت بالای ۱۳۰ کیلومتر بر ساعت! ولوم موزیک افزایش یافت. لطفا سرعت را کم کنید.'
        );
        setActiveAlert({
          id: 'overspeed-130-' + Date.now(),
          type: 'overspeed',
          title: 'هشدار سرعت بسیار بالا (۱۳۰+ km/h)',
          message: 'سرعت خودرو از ۱۳۰ رد شد. ولوم موزیک +۲۰ درجه افزایش یافت.',
          timestamp: Date.now(),
          severity: 'danger',
          durationMs: 10000,
        });
      } else if (result.level === 'boost90') {
        audioAlertService.speakPersian('عبور از سرعت ۹۰ کیلومتر بر ساعت. ولوم صدای موزیک ۱۰ درجه افزایش یافت.');
        setActiveAlert({
          id: 'boost-90-' + Date.now(),
          type: 'speed-boost',
          title: 'افزایش هوشمند ولوم موزیک (۹۰+ km/h)',
          message: 'افزایش ۱۰ درجه‌ای صدای موسیقی برای تطبیق با صدای جاده.',
          timestamp: Date.now(),
          severity: 'info',
          durationMs: 7000,
        });
      }
    }
  };

  // Simulate Incoming Phone Call
  const handleSimulateCall = () => {
    const isBt = bluetoothState.connected;
    const callData: SimulatedCall = {
      callerName: 'مهندس رضایی (نوین سیس)',
      phone: '09123456789',
      active: true,
      status: isBt ? 'ringing' : 'suppressed',
    };

    setSimulatedCall(callData);

    if (!isBt) {
      setTimeout(() => {
        setSimulatedCall(null);
      }, 4000);
    }
  };

  const handleAnswerCall = () => {
    setSimulatedCall((prev) => (prev ? { ...prev, status: 'connected' } : null));
    audioAlertService.speakPersian('تماس متصل شد.');
  };

  const handleRejectCall = () => {
    setSimulatedCall(null);
  };

  const handleTakeSnapshot = (dataUrl: string, title: string) => {
    const newSnap: MediaSnapshot = {
      id: 'snap-' + Date.now(),
      source: title.includes('جلو') ? 'driver' : 'road',
      timestamp: Date.now(),
      dataUrl,
      title,
    };
    setSnapshots((prev) => [newSnap, ...prev]);
    audioAlertService.playWarningBeep();
  };

  const handleToggleMusic = () => {
    const playing = musicPlayerService.togglePlayPause();
    setIsMusicPlaying(playing);
  };

  if (isAppPoweredOff) {
    return (
      <div className="w-screen h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-center space-y-4">
        <div className="w-20 h-20 rounded-3xl bg-slate-900 border-2 border-slate-800 flex items-center justify-center text-emerald-400 shadow-2xl">
          <Power className="w-10 h-10" />
        </div>
        <h1 className="text-xl font-black text-slate-100">دستیار هوشمند نوین سیس خاموش است</h1>
        <p className="text-xs text-slate-400 max-w-sm">
          دوربین‌ها، پایش چهره و سیستم‌های هشدار غیرفعال شدند. جهت روشن کردن مجدد لمس کنید.
        </p>
        <button
          onClick={() => setIsAppPoweredOff(false)}
          className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-sm flex items-center gap-2 shadow-xl shadow-emerald-600/30 transition-transform hover:scale-105"
        >
          <RotateCcw className="w-5 h-5" />
          <span>روشن کردن نرم‌افزار ناوبری و ایمنی</span>
        </button>
      </div>
    );
  }

  return (
    <div
      className={`relative w-screen h-screen flex flex-col overflow-hidden select-none ${
        settings.theme === 'light' ? 'bg-slate-900 text-slate-100' : 'bg-slate-950 text-slate-100'
      }`}
    >
      {/* Emergency Flash Overlay Strobe */}
      {isEmergencyStrobe && (
        <div className="fixed inset-0 z-50 pointer-events-none animate-emergency-flash border-8 border-red-600" />
      )}

      {/* Top Floating Alert Banner */}
      <AlertBannerOverlay
        activeAlert={activeAlert}
        onDismissAlert={(id) => setActiveAlert((curr) => (curr?.id === id ? null : curr))}
        isDrowsySirenActive={driverState.eyesClosed}
      />

      {/* Incoming Call Banner */}
      <IncomingCallModal
        call={simulatedCall}
        bluetoothState={bluetoothState}
        onAnswerCall={handleAnswerCall}
        onRejectCall={handleRejectCall}
      />

      {/* Main Top Header Navigation Bar */}
      <MainTopHeader
        layoutMode={layoutMode}
        onChangeLayoutMode={(mode) => setLayoutMode(mode)}
        nightVision={nightVision}
        onToggleNightVision={() => setNightVision(!nightVision)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAbout={() => setIsAboutOpen(true)}
        onOpenGallery={() => setIsGalleryOpen(true)}
        onPowerOff={() => setIsAppPoweredOff(true)}
        snapshotCount={snapshots.length}
        bluetoothState={bluetoothState}
        currentSpeedKmH={currentSpeedKmH}
        isMusicPlaying={isMusicPlaying}
        onToggleMusic={handleToggleMusic}
        musicTrackTitle={musicTrackTitle}
        speedBoostLevel={speedBoostLevel}
        hasDualCameraHardware={hasDualCameraHardware}
      />

      {/* Main Screen Body Viewports */}
      <main className="relative flex-1 w-full h-full flex flex-col overflow-hidden bg-slate-950">
        {/* MODE 1: 3-Split Screen (Only allowed if hardware has 2 separate cameras) */}
        {layoutMode === 'split-3' && hasDualCameraHardware && (
          <div className="w-full h-full flex flex-col">
            {/* TOP HALF (50%): Embedded Navigation App View */}
            <div className="w-full h-1/2 min-h-0 border-b border-slate-800">
              <NavigationAppView
                selectedAppId={settings.navApp}
                currentSpeedKmH={currentSpeedKmH}
                speedLimitKmH={speedLimitKmH}
                currentInstruction={navInstruction}
                onSelectApp={(appId) => setSettings((s) => ({ ...s, navApp: appId }))}
              />
            </div>

            {/* BOTTOM HALF (50%): Dual Cameras (Right: Rear Road Camera, Left: Front Driver Camera) */}
            <div className="w-full h-1/2 min-h-0 flex flex-row p-1 bg-slate-950 gap-1">
              {/* Right Half: Rear Road Camera */}
              <div className="w-1/2 h-full">
                <RoadCameraView
                  roadState={roadState}
                  videoStream={roadCamStream}
                  nightVision={nightVision}
                  nightVisionGamma={settings.nightVisionGamma}
                  nightVisionSaturation={settings.nightVisionSaturation}
                  onToggleNightVision={() => setNightVision(!nightVision)}
                  onUpdateNightVisionFilters={(gamma, saturation) =>
                    setSettings((s) => ({
                      ...s,
                      nightVisionGamma: gamma,
                      nightVisionSaturation: saturation,
                    }))
                  }
                  onTakeSnapshot={handleTakeSnapshot}
                />
              </div>

              {/* Left Half: Front Driver Camera */}
              <div className="w-1/2 h-full">
                <DriverCameraView
                  driverState={driverState}
                  videoStream={driverCamStream}
                  onTakeSnapshot={handleTakeSnapshot}
                  onToggleEyeState={handleToggleEyeState}
                />
              </div>
            </div>
          </div>
        )}

        {/* MODE 2: Split Driver Camera (Navigation + Front Camera) */}
        {layoutMode === 'split-driver' && (
          <div className="w-full h-full flex flex-col">
            <div className="w-full h-1/2 min-h-0 border-b border-slate-800">
              <NavigationAppView
                selectedAppId={settings.navApp}
                currentSpeedKmH={currentSpeedKmH}
                speedLimitKmH={speedLimitKmH}
                currentInstruction={navInstruction}
                onSelectApp={(appId) => setSettings((s) => ({ ...s, navApp: appId }))}
              />
            </div>
            <div className="w-full h-1/2 min-h-0 p-1">
              <DriverCameraView
                driverState={driverState}
                videoStream={driverCamStream}
                onTakeSnapshot={handleTakeSnapshot}
                onToggleEyeState={handleToggleEyeState}
              />
            </div>
          </div>
        )}

        {/* MODE 3: Split Road Camera (Navigation + Rear Camera with 10s Rear / 3s Driver cycle) */}
        {(layoutMode === 'split-road' || (layoutMode === 'split-3' && !hasDualCameraHardware)) && (
          <div className="w-full h-full flex flex-col">
            <div className="w-full h-1/2 min-h-0 border-b border-slate-800">
              <NavigationAppView
                selectedAppId={settings.navApp}
                currentSpeedKmH={currentSpeedKmH}
                speedLimitKmH={speedLimitKmH}
                currentInstruction={navInstruction}
                onSelectApp={(appId) => setSettings((s) => ({ ...s, navApp: appId }))}
              />
            </div>
            <div className="w-full h-1/2 min-h-0 p-1">
              {splitRoadSubMode === 'driver' ? (
                <DriverCameraView
                  driverState={driverState}
                  videoStream={driverCamStream}
                  onTakeSnapshot={handleTakeSnapshot}
                  onToggleEyeState={handleToggleEyeState}
                  cycleStatusText={
                    driverState.eyesClosed
                      ? '⚠️ پایش چشم: چشم راننده بسته است! تا باز شدن کامل چشم‌ها دوربین جلو فعال می‌ماند'
                      : `🟢 بررسی چشم: چشم‌ها باز هستند (بازگشت به دوربین جاده تا ${splitRoadSecLeft} ثانیه)`
                  }
                />
              ) : (
                <RoadCameraView
                  roadState={roadState}
                  videoStream={roadCamStream}
                  nightVision={nightVision}
                  nightVisionGamma={settings.nightVisionGamma}
                  nightVisionSaturation={settings.nightVisionSaturation}
                  onToggleNightVision={() => setNightVision(!nightVision)}
                  onUpdateNightVisionFilters={(gamma, saturation) =>
                    setSettings((s) => ({
                      ...s,
                      nightVisionGamma: gamma,
                      nightVisionSaturation: saturation,
                    }))
                  }
                  onTakeSnapshot={handleTakeSnapshot}
                  cycleStatusText={`دید جاده (۳۰ ثانیه) | سوئیچ به پایش چشم راننده تا ${splitRoadSecLeft} ثانیه`}
                />
              )}
            </div>
          </div>
        )}

        {/* MODE 4: Cams Only */}
        {layoutMode === 'cams-only' && (
          <div className="w-full h-full flex flex-row p-1 bg-slate-950 gap-1">
            <div className="w-1/2 h-full">
              <RoadCameraView
                roadState={roadState}
                videoStream={roadCamStream}
                nightVision={nightVision}
                nightVisionGamma={settings.nightVisionGamma}
                nightVisionSaturation={settings.nightVisionSaturation}
                onToggleNightVision={() => setNightVision(!nightVision)}
                onUpdateNightVisionFilters={(gamma, saturation) =>
                  setSettings((s) => ({
                    ...s,
                    nightVisionGamma: gamma,
                    nightVisionSaturation: saturation,
                  }))
                }
                onTakeSnapshot={handleTakeSnapshot}
              />
            </div>
            <div className="w-1/2 h-full">
              <DriverCameraView
                driverState={driverState}
                videoStream={driverCamStream}
                onTakeSnapshot={handleTakeSnapshot}
                onToggleEyeState={handleToggleEyeState}
              />
            </div>
          </div>
        )}

        {/* MODE 5: Full Navigation Only */}
        {layoutMode === 'nav-only' && (
          <div className="w-full h-full">
            <NavigationAppView
              selectedAppId={settings.navApp}
              currentSpeedKmH={currentSpeedKmH}
              speedLimitKmH={speedLimitKmH}
              currentInstruction={navInstruction}
              onSelectApp={(appId) => setSettings((s) => ({ ...s, navApp: appId }))}
            />
          </div>
        )}
      </main>

      {/* Modals */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
        bluetoothState={bluetoothState}
        onToggleBluetooth={() => setBluetoothState((b) => ({ ...b, connected: !b.connected }))}
        layoutMode={layoutMode}
        onChangeLayoutMode={(mode) => setLayoutMode(mode)}
        hasDualCameraHardware={hasDualCameraHardware}
        availableCameras={availableCameras}
        bestRearCameraId={bestRearCameraId}
        best360RearCameraId={best360RearCameraId}
        driverState={driverState}
        roadState={roadState}
        currentSpeedKmH={currentSpeedKmH}
        onSetDrowsy={handleSetDrowsy}
        onTriggerLaneDeparture={handleTriggerLaneDeparture}
        onTriggerAnimal={handleTriggerAnimal}
        onTriggerVehicleFCW={handleTriggerVehicleFCW}
        onTriggerRoadSign={handleTriggerRoadSign}
        onSpeedChange={handleSpeedChange}
        onSimulateCall={handleSimulateCall}
        onToggleNightVision={() => setNightVision(!nightVision)}
        nightVisionActive={nightVision}
        snapshots={snapshots}
        onDeleteSnapshot={(id) => setSnapshots((prev) => prev.filter((s) => s.id !== id))}
        onTakeSnapshot={handleTakeSnapshot}
      />

      <AboutModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

      <GalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        snapshots={snapshots}
        onDeleteSnapshot={(id) => setSnapshots((prev) => prev.filter((s) => s.id !== id))}
      />
    </div>
  );
}
